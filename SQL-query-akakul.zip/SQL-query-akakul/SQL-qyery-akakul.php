<?php
/*
Plugin Name: SQL Query Admin
Description: Плагин для выполнения SQL-запросов и отображения результатов на странице в админ-панели.
Version: 1.0
Author: sk8work
*/

// Запрещаем прямой доступ к файлу
if (!defined('ABSPATH')) {
    exit;
}

// Добавляем страницу плагина в админ-панель
function sql_query_admin_menu() {
    add_menu_page(
        'SQL Query', // Заголовок страницы
        'SQL Query', // Название в меню
        'manage_options', // Права доступа (только для администраторов)
        'sql-query-admin', // Уникальный идентификатор страницы
        'sql_query_admin_page', // Функция для отображения страницы
        'dashicons-database', // Иконка
        5 // Позиция в меню
    );
}
add_action('admin_menu', 'sql_query_admin_menu');

// Функция для отображения страницы плагина
function sql_query_admin_page() {
    // Проверяем права пользователя
    if (!current_user_can('manage_options')) {
        wp_die('У вас недостаточно прав для доступа к этой странице.');
    }

    global $wpdb;
    $results = [];
    $error = '';
    $query = '';

    // Обрабатываем отправку формы
    if (isset($_POST['sql_query'])) {
        // Проверяем nonce для безопасности
        if (!isset($_POST['sql_query_nonce']) || !wp_verify_nonce($_POST['sql_query_nonce'], 'sql_query_action')) {
            $error = 'Ошибка безопасности. Попробуйте еще раз.';
        } else {
            $query = stripslashes($_POST['sql_query']); // Получаем запрос из формы
            if (!empty($query)) {
                try {
                    // Выполняем SQL-запрос
                    $results = $wpdb->get_results($query, ARRAY_A);
                } catch (Exception $e) {
                    $error = 'Ошибка выполнения запроса: ' . $e->getMessage();
                }
            } else {
                $error = 'SQL-запрос не может быть пустым.';
            }
        }
    }

    // Выводим HTML-форму и результаты
    ?>
    <div class="wrap">
        <h1>SQL Query Admin</h1>
        <?php if (!empty($error)) : ?>
            <div class="notice notice-error">
                <p><?php echo esc_html($error); ?></p>
            </div>
        <?php endif; ?>

        <form method="post" action="">
            <?php wp_nonce_field('sql_query_action', 'sql_query_nonce'); ?>
            <textarea name="sql_query" rows="5" style="width: 100%;"><?php echo esc_textarea($query); ?></textarea>
            <p class="submit">
                <input type="submit" class="button-primary" value="Выполнить запрос">
            </p>
        </form>

        <?php if (!empty($results)) : ?>
            <h2>Результаты запроса</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <?php foreach (array_keys($results[0]) as $column) : ?>
                            <th><?php echo esc_html($column); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $row) : ?>
                        <tr>
                            <?php foreach ($row as $cell) : ?>
                                <td><?php echo esc_html($cell); ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php elseif (isset($_POST['sql_query'])) : ?>
            <p>Нет данных для отображения.</p>
        <?php endif; ?>
    </div>
    <?php
}

?>