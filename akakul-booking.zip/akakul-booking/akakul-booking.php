<?php
/*
Plugin Name: Akakul Booking
Description: Плагин для бронирования товаров. Добавляет кнопку "Забронировать" рядом с кнопкой "Купить", переводит на отдельную страницу для бронирования и отправляет подтверждение по email.
Version: 1.2
Author: sk8work
*/

if (!defined('ABSPATH')) {
    exit; // Выход, если файл вызывается напрямую
}

//Подключаем файлы стилей
//admin
function akakul_booking_admin_enqueue_styles() {
    wp_register_style(
        'akakul-booking-admin-style',
        plugins_url('assets/css/admin-style.css', __FILE__),
        array(),
        filemtime(plugin_dir_path(__FILE__) . 'assets/css/admin-style.css')
    );

    wp_enqueue_style('akakul-booking-admin-style');
}
// frontend
function akakul_booking_frontend_enqueue_styles() {
    wp_register_style(
        'akakul-booking-frontend-style',
        plugins_url('assets/css/frontend-style.css', __FILE__),
        array(),
        filemtime(plugin_dir_path(__FILE__) . 'assets/css/frontend-style.css')
    );

    wp_enqueue_style('akakul-booking-frontend-style');
}
add_action('admin_enqueue_scripts', 'akakul_booking_admin_enqueue_styles');

//Подключаем скрипты
function akakul_booking_enqueue_scripts() {
    wp_enqueue_script(
        'akakul-booking-frontend-script',
        plugins_url('assets/js/frontend-script.js', __FILE__),
        array('jquery'),
        filemtime(plugin_dir_path(__FILE__) . 'assets/js/frontend-script.js'),
        true
    );                                   

    // Подключаем библиотеку jQuery Mask Plugin
    wp_enqueue_script(
        'jquery-mask-plugin',
        plugins_url('assets/js/jquery.mask.min.js', __FILE__),
        array('jquery'),
        '1.14.16',
        true
    );
}
add_action('wp_enqueue_scripts', 'akakul_booking_enqueue_scripts');


// Создаем таблицу при активации плагина
register_activation_hook(__FILE__, 'create_booking_table');

function create_booking_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'woocommerce_bookings';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        product_id mediumint(9) NOT NULL,
        product_name varchar(255) NOT NULL,
        parent_name varchar(255) NOT NULL,
        child_name varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        phone varchar(50) NOT NULL,
        child_bdate varchar(50) NOT NULL,
        booking_date datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        confirmation_token varchar(64) DEFAULT NULL,
        is_confirmed tinyint(1) DEFAULT 0,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Удаляем таблицу при удалении плагина
register_uninstall_hook(__FILE__, 'delete_booking_table');

function delete_booking_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'woocommerce_bookings';

    // Удаляем таблицу, если она существует
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
}




//Подключаем логику и обработчики
require('includes/class-akakul-booking-frontend.php');

include('includes/class-akakul-booking-admin.php');

include('includes/class-akakul-booking-manual.php');

// Регистрируем задачу WP Cron для очистки не подтвержденных бронирований
register_activation_hook(__FILE__, 'schedule_booking_cleanup');

function schedule_booking_cleanup() {
    if (!wp_next_scheduled('akakul_booking_cleanup')) {
        wp_schedule_event(time(), 'hourly', 'akakul_booking_cleanup');
    }
}

add_action('akakul_booking_cleanup', 'cleanup_unconfirmed_bookings');

function cleanup_unconfirmed_bookings() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'woocommerce_bookings';

    // Находим все бронирования, которые не подтверждены и старше 24 часов
    $unconfirmed_bookings = $wpdb->get_results(
        "SELECT * FROM $table_name WHERE is_confirmed = 0 AND booking_date < NOW() - INTERVAL 1 DAY"
    );

    foreach ($unconfirmed_bookings as $booking) {
        // Возвращаем товар на склад
        $product = wc_get_product($booking->product_id);
        if ($product) {
            $current_stock = $product->get_stock_quantity();
            $product->set_stock_quantity($current_stock + 1);
            $product->save();
        }

        // Удаляем бронирование
        $wpdb->delete($table_name, array('id' => $booking->id));
    }
}

// Удаляем задачу WP Cron при деактивации плагина
register_deactivation_hook(__FILE__, 'unschedule_booking_cleanup');

function unschedule_booking_cleanup() {
    $timestamp = wp_next_scheduled('akakul_booking_cleanup');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'akakul_booking_cleanup');
    }
}
?>