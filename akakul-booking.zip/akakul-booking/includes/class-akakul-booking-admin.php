<?php

if (!defined('ABSPATH')) {
    exit;
}

class WooCommerce_Booking_Admin {

    public function __construct() {
        add_action('admin_menu', array($this, 'add_booking_admin_page'));
        add_action('admin_menu', array($this, 'add_sql_query_page')); // Добавляем сюда
        add_action('admin_init', array($this, 'handle_delete_booking'));
        add_action('admin_init', array($this, 'handle_export_excel'));
    }

    public function add_booking_admin_page() {
        add_menu_page(
            __('Бронирования', 'woocommerce-booking'), // Заголовок страницы
            __('Бронирования', 'woocommerce-booking'), // Название в меню
            'edit_posts', // Права доступа
            'woocommerce-bookings', // Slug страницы
            array($this, 'render_booking_admin_page'), // Функция для отображения страницы
            'dashicons-calendar-alt', // Иконка
            6 // Позиция в меню
        );
    }

    public function add_sql_query_page() {
        add_submenu_page(
            'woocommerce-bookings', // Родительский slug (страница бронирований)
            __('Настройки', 'woocommerce-booking'), // Заголовок страницы
            __('Настройки', 'woocommerce-booking'), // Название в меню
            'manage_options', // Права доступа
            'sql-query', // Slug страницы
            array($this, 'render_sql_query_page'), // Функция для отображения страницы,
            'dashicons-admin-generic',
            10
        );
    }
    

    public function render_booking_admin_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'woocommerce_bookings';

        // Обработка снятия бронирования
        if (isset($_GET['action']) && $_GET['action'] === 'unbook' && isset($_GET['id'])) {
            if (!wp_verify_nonce($_GET['_wpnonce'], 'unbook_booking_' . $_GET['id'])) {
                wp_die(__('Недействительный запрос.', 'woocommerce-booking'));
            }

            $booking_id = intval($_GET['id']);
            $wpdb->update(
                $table_name,
                array('is_confirmed' => 0), // Снимаем бронирование
                array('id' => $booking_id)
            );

            wp_redirect(admin_url('admin.php?page=woocommerce-bookings'));
            exit;
        }

        // Обработка подтверждения бронирования
        if (isset($_GET['action']) && $_GET['action'] === 'confirm' && isset($_GET['id'])) {
            if (!wp_verify_nonce($_GET['_wpnonce'], 'confirm_booking_' . $_GET['id'])) {
                wp_die(__('Недействительный запрос.', 'woocommerce-booking'));
            }

            $booking_id = intval($_GET['id']);
            $wpdb->update(
                $table_name,
                array('is_confirmed' => 1), // Подтверждаем бронирование
                array('id' => $booking_id)
            );

            wp_redirect(admin_url('admin.php?page=woocommerce-bookings'));
            exit;
        }

        // Фильтры
        $filter_product_name    = isset($_GET['filter_product_name']) ? sanitize_text_field($_GET['filter_product_name']) : '';
        $filter_parent_name     = isset($_GET['filter_parent_name']) ? sanitize_text_field($_GET['filter_parent_name']) : '';
        $filter_child_name      = isset($_GET['filter_child_name']) ? sanitize_text_field($_GET['filter_child_name']) : '';
        $filter_child_bdate     = isset($_GET['filter_child_bdate']) ? sanitize_text_field($_GET['filter_child_bdate']) : '';
        $filter_email           = isset($_GET['filter_email']) ? sanitize_text_field($_GET['filter_email']) : '';
        $filter_phone           = isset($_GET['filter_phone']) ? sanitize_text_field($_GET['filter_phone']) : '';
        $filter_booking_date    = isset($_GET['filter_booking_date']) ? sanitize_text_field($_GET['filter_booking_date']) : '';
        $filter_confirmed       = isset($_GET['filter_confirmed']) ? sanitize_text_field($_GET['filter_confirmed']) : '';

        // Формируем SQL-запрос с учетом фильтров
        $where = array();
        if ($filter_product_name) {
            $where[] = $wpdb->prepare("product_name LIKE %s", "%$filter_product_name%");
        }
        if ($filter_parent_name) {
            $where[] = $wpdb->prepare("parent_name LIKE %s", "%$filter_parent_name%");
        }
        if ($filter_child_name) {
            $where[] = $wpdb->prepare("child_name LIKE %s", "%$filter_child_name%");
        }
        if ($filter_child_bdate) {
            $where[] = $wpdb->prepare("child_bdate = %s", $filter_child_bdate);
        }
        if ($filter_email) {
            $where[] = $wpdb->prepare("email LIKE %s", "%$filter_email%");
        }
        if ($filter_phone) {
            $where[] = $wpdb->prepare("phone LIKE %s", "%$filter_phone%");
        }
        if ($filter_booking_date) {
            $where[] = $wpdb->prepare("DATE(booking_date) = %s", $filter_booking_date);
        }
        if ($filter_confirmed !== '') {
            $where[] = $wpdb->prepare("is_confirmed = %d", $filter_confirmed);
        }
        $where = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        // Пагинация
        $per_page = 20;
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($current_page - 1) * $per_page;

        // Общее количество записей
        $total_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name $where");

        // Получаем записи с учетом фильтров и пагинации
        $bookings = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name $where ORDER BY booking_date DESC LIMIT %d OFFSET %d",
            $per_page,
            $offset
        ));

        echo '<div class="wrap">';
        echo '<h1>' . __('Бронирования', 'woocommerce-booking') . '</h1>';

        // Кнопка экспорта
        echo '<div class="tablenav top export" >';
        echo '<p>Количество записей: <strong>'.$total_items.'</strong><p>';
        echo '<a href="' . admin_url('admin.php?page=woocommerce-bookings&action=export_excel') . '" class="button">Экспорт в Excel</a>';
        echo '</div>';

        // Пагинация
        $pagination = paginate_links(array(
            'base'      => add_query_arg('paged', '%#%'),
            'format'    => '',
            'current'   => $current_page,
            'total'     => ceil($total_items / $per_page),
            'add_args'  => array(
                'filter_product_name'   => $filter_product_name,
                'filter_parent_name'    => $filter_parent_name,
                'filter_child_name'     => $filter_child_name,
                'filter_child_bdate'    => $filter_child_bdate,
                'filter_email'          => $filter_email,
                'filter_phone'          => $filter_phone,
                'filter_booking_date'   => $filter_booking_date,
                'filter_confirmed'      => $filter_confirmed,
            ),
        ));

        if ($pagination) {
            echo '<div class="tablenav top">';
            echo '<div class="tablenav-pages">' . $pagination . '</div>';
            echo '</div>';
        }

        // Таблица с записями
        echo '<table class="wp-list-table widefat fixed striped admin-booking-table">';
        echo '<thead>
                <tr><form method="get" action="' . admin_url('admin.php') . '">
                        <input type="hidden" name="page" value="woocommerce-bookings">
                        <th class="number">№</th>
                        <th><p>Товар</p><input type="text" name="filter_product_name" id="filter_product_name" value="' . esc_attr($filter_product_name) . '"></th>
                        <th><p>Ф.И.О. родителя</p><input type="text" name="filter_parent_name" id="filter_parent_name" value="' . esc_attr($filter_parent_name) . '"></th>
                        <th><p>Ф.И.О. ребенка</p><input type="text" name="filter_child_name" id="filter_child_name" value="' . esc_attr($filter_child_name) . '"></th>
                        <th><p>Д.р. ребенка</p><input class="date" type="date" name="filter_child_bdate" id="filter_child_bdate" value="' . esc_attr($filter_child_bdate) . '"></th>
                        <th><p>Email</p><input type="text" name="filter_email" id="filter_email" value="' . esc_attr($filter_email) . '"></th>
                        <th><p>Телефон</p><input type="text" name="filter_phone" id="filter_phone" value="' . esc_attr($filter_phone) . '"></th>
                        <th><p>Дата брони</p><input class="date" type="date" name="filter_booking_date" id="filter_booking_date" value="' . esc_attr($filter_booking_date) . '"></th>
                        <th class="option"><p>Подтверждено</p><select name="filter_confirmed" id="filter_confirmed">
                            <option value="">Все</option>
                            <option value="1"' . selected($filter_confirmed, '1', false) . '>Да</option>
                            <option value="0"' . selected($filter_confirmed, '0', false) . '>Нет</option>
                            </select></th>
                        <th><p>Действия</p>
                        <div class="filter-buttons">
                        <input type="submit" class="button filter-button" id="filt"  value="Фильтровать">
                        <a href="' . admin_url('admin.php?page=woocommerce-bookings') . '" class="button reset-button" id="reset_filt" style="background-color:#E14D43; color:white; text-align:center">Сбросить фильтры</a>
                    </div>
                        </th>
                </form></tr>
              </thead>';
        echo '<tbody>';
        
        foreach ($bookings as $booking) {
            $product        = wc_get_product($booking->product_id);
            $product_name   = $product ? $product->get_name() : 'Товар удален';

            echo '<tr class="table-body">
                    <td>' . esc_html($booking->id) . '</td>
                    <td>' . esc_html($product_name) . '</td>
                    <td>' . esc_html($booking->parent_name) . '</td>
                    <td>' . esc_html($booking->child_name) . '</td>
                    <td>' . esc_html($booking->child_bdate) . '</td>
                    <td>' . esc_html($booking->email) . '</td>
                    <td>' . esc_html($booking->phone) . '</td>
                    <td>' . esc_html($booking->booking_date) . '</td>
                    <td>' . ($booking->is_confirmed ? 'Да' : 'Нет') . '</td>
                    <td>';

            if ($booking->is_confirmed) {
                // Если бронирование подтверждено, показываем кнопку "Снять бронирование"
                echo '<a href="' . wp_nonce_url(admin_url('admin.php?page=woocommerce-bookings&action=unbook&id=' . $booking->id), 'unbook_booking_' . $booking->id) . '" class="button button-secondary">Снять</a>';
            } else {
                // Если бронирование не подтверждено, показываем кнопку "Подтвердить бронирование"
                echo '<a href="' . wp_nonce_url(admin_url('admin.php?page=woocommerce-bookings&action=confirm&id=' . $booking->id), 'confirm_booking_' . $booking->id) . '" class="button button-secondary">Подтвердить</a>';
            }

            echo '<a href="' . wp_nonce_url(admin_url('admin.php?page=woocommerce-bookings&action=delete&id=' . $booking->id), 'delete_booking_' . $booking->id) . '" class="button button-primary">Удалить</a>
                    </td>
                  </tr>';    
        }

        echo '</tbody>';
        echo '</table>';

        if ($pagination) {
            echo '<div class="tablenav bottom">';
            echo '<div class="tablenav-pages">' . $pagination . '</div>';
            echo '</div>';
        }

        echo '</div>';
    }

    public function handle_delete_booking() {
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
            if (!wp_verify_nonce($_GET['_wpnonce'], 'delete_booking_' . $_GET['id'])) {
                wp_die(__('Недействительный запрос.', 'woocommerce-booking'));
            }
    
            global $wpdb;
            $table_name = $wpdb->prefix . 'woocommerce_bookings';
    
            // Получаем данные о бронировании
            $booking = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", intval($_GET['id'])));
    
            if ($booking) {
                // Возвращаем товар на склад
                $product = wc_get_product($booking->product_id);
                if ($product) {
                    $current_stock = $product->get_stock_quantity();
                    $product->set_stock_quantity($current_stock + 1);
                    $product->save();
                }
    
                // Удаляем бронирование
                $wpdb->delete($table_name, array('id' => intval($_GET['id'])));
            }
    
            wp_redirect(admin_url('admin.php?page=woocommerce-bookings'));
            exit;
        }
    }

    public function handle_export_excel() {
        if (isset($_GET['action']) && $_GET['action'] === 'export_excel') {
            global $wpdb;
            $table_name = $wpdb->prefix . 'woocommerce_bookings';

            $bookings = $wpdb->get_results("SELECT * FROM $table_name ORDER BY booking_date DESC");

            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment; filename="bookings.xls"');

            echo "ID\tТовар\tФ.И.О. родителя\tФ.И.О. ребенка\tДата рождения ребенка\tEmail\tТелефон\tДата бронирования\tПодтверждено\n";

            foreach ($bookings as $booking) {
                $product = wc_get_product($booking->product_id);
                $product_name = $product ? $product->get_name() : 'Товар удален';

                echo $booking->id . "\t";
                echo $product_name . "\t";
                echo $booking->parent_name . "\t";
                echo $booking->child_name . "\t";
                echo $booking->child_bdate . "\t";
                echo $booking->email . "\t";
                echo $booking->phone . "\t";
                echo $booking->booking_date . "\t";
                echo ($booking->is_confirmed ? 'Да' : 'Нет') . "\n";
            }

            exit;
        }
    }


    public function render_sql_query_page() {
        // Проверяем права доступа
        if (!current_user_can('manage_options')) {
            wp_die(__('У вас недостаточно прав для доступа к этой странице.', 'woocommerce-booking'));
        }
    
        global $wpdb;
        $results = [];
        $error = '';
        $query = '';
    
        // Обрабатываем отправку формы
        if (isset($_POST['sql_query'])) {
            // Проверяем nonce для безопасности
            if (!isset($_POST['sql_query_nonce']) || !wp_verify_nonce($_POST['sql_query_nonce'], 'sql_query_action')) {
                $error = 'Ошибка безопасности. Попробуйте еще раз.';
            } else {
                $query = stripslashes($_POST['sql_query']); // Получаем запрос из формы
                if (!empty($query)) {
                    try {
                        // Выполняем SQL-запрос
                        $results = $wpdb->get_results($query, ARRAY_A);
                    } catch (Exception $e) {
                        $error = 'Ошибка выполнения запроса: ' . $e->getMessage();
                    }
                } else {
                    $error = 'SQL-запрос не может быть пустым.';
                }
            }
        }
    
        // Выводим HTML-форму и результаты
        ?>
        <div class="wrap">
            <h1><?php _e('SQL Запросы', 'woocommerce-booking'); ?></h1>
            <?php if (!empty($error)) : ?>
                <div class="notice notice-error">
                    <p><?php echo esc_html($error); ?></p>
                </div>
            <?php endif; ?>
    
            <form method="post" action="">
                <?php wp_nonce_field('sql_query_action', 'sql_query_nonce'); ?>
                <textarea name="sql_query" rows="5" style="width: 100%;"><?php echo esc_textarea($query); ?></textarea>
                <p class="submit">
                    <input type="submit" class="button-primary" value="<?php _e('Выполнить запрос', 'woocommerce-booking'); ?>">
                </p>
            </form>
    
            <?php if (!empty($results)) : ?>
                <h2><?php _e('Результаты запроса', 'woocommerce-booking'); ?></h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <?php foreach (array_keys($results[0]) as $column) : ?>
                                <th><?php echo esc_html($column); ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                    foreach ($results as $row) : ?>
                        <tr>
                            <?php foreach ($row as $value) : ?>
                                <td><?php echo esc_html($value); ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
}
    
}

// Инициализация класса
new WooCommerce_Booking_Admin();

?>