<?php
/*
Plugin Name: Booking System
Description: Система бронирования билетов для ДОЛ "Акакуль".
Version: 1.0
Author: Polina
*/

// Подключение необходимых файлов
include_once(plugin_dir_path(__FILE__) . 'includes/booking-functions.php');
include_once(plugin_dir_path(__FILE__) . 'includes/booking-admin.php');


// Активация плагина
register_activation_hook(__FILE__, 'create_booking_table');

function create_booking_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'wfm_bookings';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        parent_name tinytext NOT NULL,
        parent_email varchar(100) NOT NULL,
        parent_phone varchar(15) NOT NULL,
        child_name tinytext NOT NULL,
        child_birth_date date NOT NULL,
        school tinytext NOT NULL,
        age int NOT NULL,
        class tinytext NOT NULL,
        address tinytext NOT NULL,
        snils varchar(11) NOT NULL,
        shift varchar(10) NOT NULL,
        confirmation_code varchar(6) NOT NULL,
        status varchar(20) DEFAULT 'pending',
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    dbDelta($sql);
}
function booking_enqueue_scripts() {
    wp_enqueue_style('booking-style', plugins_url('css/style.css', __FILE__));
    wp_enqueue_script('jquery');
}
add_action('wp_enqueue_scripts', 'booking_enqueue_scripts');


?>