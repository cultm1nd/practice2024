<?php

class BookingAdmin {
    public function __construct() {
        add_action('admin_menu', array($this, 'create_admin_menu'));
        add_action('admin_init', array($this, 'handle_booking_actions'));
    }

    public function create_admin_menu() {
        add_menu_page('Управление бронированиями', 'Бронирования', 'manage_options', 'booking-management', array($this, 'display_bookings'));
    }

    public function display_bookings() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wfm_bookings';
        $bookings = $wpdb->get_results("SELECT * FROM $table_name");

        echo '<h1>Управление бронированиями</h1>';
        echo '<table>';
        echo '<tr><th>ID</th><th>ФИО родителя</th><th>ФИО ребенка</th><th>Статус</th><th>Действия</th></tr>';

        foreach ($bookings as $booking) {
            echo '<tr>';
            echo '<td>' . esc_html($booking->id) . '</td>';
            echo '<td>' . esc_html($booking->parent_name) . '</td>';
            echo '<td>' . esc_html($booking->child_name) . '</td>';
            echo '<td>' . esc_html($booking->status) . '</td>';
            echo '<td>';
            echo '<form method="POST" action="">';
            echo '<input type="hidden" name="booking_id" value="' . esc_attr($booking->id) . '">';
            echo '<select name="booking_status">';
            echo '<option value="pending"' . selected($booking->status, 'pending', false) . '>В ожидании</option>';
            echo '<option value="confirmed"' . selected($booking->status, 'confirmed', false) . '>Подтверждено</option>';
            echo '<option value="canceled"' . selected($booking->status, 'canceled', false) . '>Отменено</option>';
            echo '</select>';
            echo '<button type="submit" name="update_booking">Обновить</button>';
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        }

        echo '</table>';
    }

    public function handle_booking_actions() {
        if (isset($_POST['update_booking'])) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'wfm_bookings';
            $booking_id = intval($_POST['booking_id']);
            $new_status = sanitize_text_field($_POST['booking_status']);

            // Обновление статуса бронирования
            $wpdb->update(
                $table_name,
                array('status' => $new_status),
                array('id' => $booking_id)
            );

            // Перенаправление обратно на страницу управления бронированиями
            wp_redirect(admin_url('admin.php?page=booking-management'));
            exit;
        }
    }
}

new BookingAdmin();


// Добавляем страницу в админку
function booking_add_admin_menu() {
    add_menu_page(
        'Система Бронирования', // Название страницы
        'Бронирование', // Название меню
        'manage_options', // Возможности
        'booking_system', // Уникальный слаг
        'booking_admin_page', // Функция, которая выводит содержимое страницы
        'dashicons-calendar-alt', // Иконка меню
        20 // Позиция в меню
    );
}
add_action('admin_menu', 'booking_add_admin_menu');

// Функция, которая выводит содержимое страницы
function booking_admin_page() {
    ?>
    <div class="wrap">
        <h1>Управление Бронированиями</h1>
        <p>Здесь вы можете управлять бронированиями.</p>
        
        <!-- Здесь можно добавить таблицу с бронированиями или другие элементы управления -->
        <table class="widefat fixed">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Имя родителя</th>
                    <th>Email</th>
                    <th>Телефон</th>
                    <th>Имя ребенка</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody>
                <?php
                global $wpdb;
                $table_name = $wpdb->prefix . 'wfm_bookings';
                $bookings = $wpdb->get_results("SELECT * FROM $table_name");

                foreach ($bookings as $booking) {
                    echo "<tr>
                        <td>{$booking->id}</td>
                        <td>{$booking->parent_name}</td>
                        <td>{$booking->parent_email}</td>
                        <td>{$booking->parent_phone}</td>
                        <td>{$booking->child_name}</td>
                        <td>{$booking->status}</td>
                    </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
}

?>