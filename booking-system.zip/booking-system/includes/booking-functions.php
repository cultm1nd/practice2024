<?php
class BookingSystem {
    public function __construct() {
        add_shortcode('booking_form', array($this, 'render_booking_form'));
        add_action('wp_ajax_nopriv_send_confirmation_code', array($this, 'send_confirmation_code'));
        add_action('wp_ajax_send_confirmation_code', array($this, 'send_confirmation_code'));
    }

    public function render_booking_form() {
        ob_start();
        ?>
        <form id="booking-form" method="POST">
            <h3>Данные родителя</h3>
            <label for="parent_name">ФИО родителя</label>
            <input type="text" id="parent_name" name="parent_name" required>

            <label for="parent_email">Электронная почта</label>
            <input type="email" id="parent_email" name="parent_email" required>

            <label for="parent_phone">Телефон</label>
            <input type="tel" id="parent_phone" name="parent_phone" required>

            <h3>Данные о ребенке</h3>
            <label for="child_name">ФИО ребенка</label>
            <input type="text" id="child_name" name="child_name" required>

            <label for="child_birth_date">Дата рождения</label>
            <input type="date" id="child_birth_date" name="child_birth_date" required>

            <label for="school">Школа</label>
            <input type="text" id="school" name="school" required>

            <label for="age">Полных лет</label>
            <input type="number" id="age" name="age" required>

            <label for="class">Класс</label>
            <input type="text" id="class" name="class" required>

            <label for="address">Адрес проживания</label>
            <input type="text" id="address" name="address" required>

            <label for="snils">СНИЛС</label>
            <input type="text" id="snils" name="snils" required>

            <label for="shift">
            <label for="shift">Выбор смены</label>
                <select id="shift" name="shift" required>
                    <option value="morning">Утренний</option>
                    <option value="afternoon">Дневной</option>
                </select>

                <label>
                    <input type="checkbox" name="consent" required> Согласие на обработку персональных данных
                </label>

                <button type="submit">Забронировать билет</button>
            </form>

            <div id="response"></div>

            <script>
                jQuery(document).ready(function($) {
                    $('#booking-form').on('submit', function(e) {
                        e.preventDefault();
                        $.ajax({
                            url: '<?php echo admin_url("admin-ajax.php"); ?>',
                            type: 'POST',
                            data: $(this).serialize() + '&action=send_confirmation_code',
                            success: function(response) {
                                $('#response').html(response.data);
                            },
                            error: function() {
                                $('#response').html('Произошла ошибка. Попробуйте еще раз.');
                            }
                        });
                    });
                });
            </script>
            <?php
            return ob_get_clean();
        }

        public function send_confirmation_code() {
            global $wpdb;

            // Валидация и очистка данных
            $parent_name = sanitize_text_field($_POST['parent_name']);
            $parent_email = sanitize_email($_POST['parent_email']);
            $parent_phone = sanitize_text_field($_POST['parent_phone']);
            $child_name = sanitize_text_field($_POST['child_name']);
            $child_birth_date = sanitize_text_field($_POST['child_birth_date']);
            $school = sanitize_text_field($_POST['school']);
            $age = intval($_POST['age']);
            $class = sanitize_text_field($_POST['class']);
            $address = sanitize_text_field($_POST['address']);
            $snils = sanitize_text_field($_POST['snils']);
            $shift = sanitize_text_field($_POST['shift']);

            // Генерация кода подтверждения
            $confirmation_code = rand(100000, 999999);

            // Сохранение данных в базу данных
            $table_name = $wpdb->prefix . 'wfm_bookings';
            $data = array(
                'parent_name' => $parent_name,
                'parent_email' => $parent_email,
                'parent_phone' => $parent_phone,
                'child_name' => $child_name,
                'child_birth_date' => $child_birth_date,
                'school' => $school,
                'age' => $age,
                'class' => $class,
                'address' => $address,
                'snils' => $snils,
                'shift' => $shift,
                'confirmation_code' => $confirmation_code,
            );

            $wpdb->insert($table_name, $data);

            // Отправка кода подтверждения по SMS (псевдокод, замените на вашу логику)
            // send_sms($parent_phone, $confirmation_code); // Реализуйте функцию для отправки SMS

            // Ответ клиенту
            wp_send_json_success('Ваш код подтверждения: ' . $confirmation_code);
        }
    }

    new BookingSystem();

?>