<?php
    // Подключение шапки сайта
    include("../include/header.php");
    // Подключение функций
    include("../function/function.php");
    // Проверка авторизован ли пользователь
    if(!isset($_SESSION['login'])){
        header('location: /');
        exit;
    }
    // Проверка является ли пользователь администратором
    if($_SESSION['role'] != 'admin'){
        header('location: /profile/');
        exit;
    }
?>

    <!--здесь будет контент-->

    <section>
    <div class="container py-3">
        <h3 class="display-3 text-center">Панель администратора</h3>

        <div class="d-flex align-items-start my-5">
            <div class="nav flex-column nav-pills me-3 w-25" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                <button class="nav-link active" id="v-pills-all-tab" data-bs-toggle="pill" data-bs-target="#v-pills-all" type="button" role="tab" aria-controls="v-pills-all" aria-selected="true">Все заявки</button>
                <button class="nav-link" id="v-pills-new-tab" data-bs-toggle="pill" data-bs-target="#v-pills-new" type="button" role="tab" aria-controls="v-pills-new" aria-selected="false">Новые заявки</button>
                <button class="nav-link" id="v-pills-canceled-tab" data-bs-toggle="pill" data-bs-target="#v-pills-canceled" type="button" role="tab" aria-controls="v-pills-canceled" aria-selected="false">Отмененные заявки</button>
                <button class="nav-link" id="v-pills-confirmed-tab" data-bs-toggle="pill" data-bs-target="#v-pills-confirmed" type="button" role="tab" aria-controls="v-pills-confirmed" aria-selected="false">Подтвержденные заявки</button>
                <button class="nav-link" id="v-pills-process-tab" data-bs-toggle="pill" data-bs-target="#v-pills-process" type="button" role="tab" aria-controls="v-pills-process" aria-selected="false">Заявки в процессе</button>
            </div>
            <div class="tab-content w-75" id="v-pills-tabContent">
                <div class="tab-pane fade active show" id="v-pills-all" role="tabpanel" aria-labelledby="v-pills-all-tab" tabindex="0"><?=fnOutCardAdmin()?></div>
                <div class="tab-pane fade" id="v-pills-new" role="tabpanel" aria-labelledby="v-pills-new-tab" tabindex="0"><?=fnOutCardAdminStatus('new')?></div>
                <div class="tab-pane fade" id="v-pills-canceled" role="tabpanel" aria-labelledby="v-pills-canceled-tab" tabindex="0"><?=fnOutCardAdminStatus('canceled')?></div>
                <div class="tab-pane fade" id="v-pills-confirmed" role="tabpanel" aria-labelledby="v-pills-confirmed-tab" tabindex="0"><?=fnOutCardAdminStatus('confirmed')?></div>
                <div class="tab-pane fade" id="v-pills-process" role="tabpanel" aria-labelledby="v-pills-process-tab" tabindex="0"><?=fnOutCardAdminStatus('process')?></div>
            </div>
        </div>
    </div>
</section>

<?php
    include ("../include/footer.php");
?>

