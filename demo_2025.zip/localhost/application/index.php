<?php
    include ("../include/header.php");
    include ("../function/function.php");

    // Проверка авторизован ли пользователь
    if(!isset($_SESSION['login'])){
        header('location: /');
        exit;
    }
?>

<section>
    <div class="container py-3">
        <h3 class="display-3 text-center">Подача заявки</h3>
        <div class="image w-50 mx-auto my-4">
            <img src="/assets/media/application.jpg" alt="application" class="w-100 rounded-pill">
        </div>
        <form action="/admin/controllers/add_application.php" method="post" novalidate class="needs-validation w-50 mx-auto"> 
            <div class="mb-3">
                <label for="address" class="form-label fs-3">Адрес</label>
                <input type="text" class="form-control fs-3 rounded-pill shadow-sm px-3" id="address" name="address" required >
                <div class="invalid-feedback fs-4">
                   Поле обязательно для заполнения
                </div>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label fs-3">Телефон</label>
                <input type="tel" class="form-control fs-3 rounded-pill shadow-sm px-3" id="phone" name="phone" required pattern="\+?[0-9(\)\-\]+" placeholder="+7(XXX)-XXX-XX-XX" minlength="17" maxlength="17">
                <div class="invalid-feedback fs-4">
                   Поле обязательно для заполнения
                </div>
            </div>
            <div class="mb-3">
                <label for="date" class="form-label fs-3">Желаемая дата</label>
                <input type="date" class="form-control fs-3 rounded-pill shadow-sm px-3" id="date" name="date" required>
                <div class="invalid-feedback fs-4">
                   Поле обязательно для заполнения
                </div>
            </div>
            <div class="mb-3">
                <label for="time" class="form-label fs-3">Желаемое время</label>
                <input type="time" class="form-control fs-3 rounded-pill shadow-sm px-3" id="time" name="time" required>
                <div class="invalid-feedback fs-4">
                   Поле обязательно для заполнения
                </div>
            </div>
            
            <div class="mb-3">
                <label for="category" class="form-label fs-3">Вид услуги</label>
                <select class="form-select form-select-lg fs-3 rounded-pill shadow-sm px-3" id="category" name="category">
                    <?=fnOutService()?>
                </select>
            </div>
            <div class="mb-3 form-check p-0">
                <input class="form-check-input p-3 ms-2" type="checkbox" value="" id="service">
                <label class="form-check-label fs-3 ms-3" for="service">
                    Иная услуга
                </label>
                <div class="service">
                    <label for="description" class="form-label fs-3">Описание</label>
                    <textarea class="form-control fs-3 rounded-5 shadow-sm" rows="6" id="description" name="description"></textarea>
                    <div class="invalid-feedback fs-4">
                    Поле обязательно для заполнения
                    </div>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="pay" class="form-label fs-3">Способ оплаты</label>
                <select class="form-select form-select-lg fs-3 rounded-pill shadow-sm px-3" id="pay" name="pay">
                    <?=fnOutPay()?>
                </select>
            </div>
            
            <button type="submit" class="btn btn-success p-3 rounded-pill shadow-sm fw-bold w-100 fs-3 my-3">Сформировать заявку</button>
        </form>
    </div>
</section>



<?php
    include ("../include/footer.php");
?>
