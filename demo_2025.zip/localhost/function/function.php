<?php
    include "connect.php";

    function fnOutService(){
        global $connect;
        $sql = "SELECT * FROM `service` WHERE `id_service` > 0";
        $result = $connect->query($sql);
        $data = "";
        foreach($result as $item){
            $data .= sprintf('<option value="%s">%s</option>', $item['id_service'],
                                                               $item["name"]);
        }
        return $data;
    }
    
    function fnOutPay(){
        global $connect;
        $sql = "SELECT * FROM `pay`";
        $result = $connect->query($sql);
        $data = "";
        foreach($result as $item){
            $data .= sprintf('<option value="%s">%s</option>', $item['id_pay'], $item["name"]);
        }
        return $data;
    }
    

    // Простая реализация вывода

    // function fnOutCardProfile($login){
    //     global $connect;
    //     $sql = "SELECT * FROM `user` WHERE `login` = '{$login}'";
    //     $result = $connect->query($sql);
    //     $user = $result->fetch_assoc();
    //     $sql = "SELECT `id_application`, `status`,`status_info`, `date`, `time`,
    //            `pay`.`name` AS `pname`, `service`.`name` AS `sname`, `code`,
    //             `description`, `service`.`id_service` FROM `application` INNER JOIN
    //             `service` ON `application`.`id_service` = `service`.`id_service`
    //             INNER JOIN `pay` ON `application`.`id_pay` = `pay`.`id_pay`
    //             INNER JOIN `status` ON `application`.`id_status` =   
    //             `status`.`id_status` WHERE `application`.`id_user` = 
    //             {$user['id_user']} ORDER BY `id_application` DESC";
    //     $result = $connect->query($sql);
    //     if(!$result->num_rows){
    //         $data = "<h4 class='display-6 text-center'>Заявок не найдено<h4>";
    //     }else{
    //         $data = "<div class='cards my-4 row row-cols-1 row-cols-md-3 g-4'>";
    
    //         foreach($result as $item){
    //             $data .= sprintf('
    //                 <div class="col">
    //                     <div class="card mb-3">
    //                         <div class="card-body">
    //                         <h5 class="card-title fs-3">Заявка №%s</h5>
    //                             <p class="card-text mb-2">
    //                                 <span class="fw-semibold">Статус заявки</span>: %s
    //                             </p>
    //                             <p class="card-text mb-2">
    //                                 <span class="fw-semibold">Категория</span>: %s
    //                             </p>
    //                             <p class="card-text mb-2">
    //                                 <span class="fw-semibold">Дата</span>: %s
    //                             </p>
    //                             <p class="card-text mb-2">
    //                                 <span class="fw-semibold">Время</span>: %s
    //                             </p>
    //                             <p class="card-text mb-2">
    //                                 <span class="fw-semibold">Способ оплаты</span>: %s
    //                             </p>
    //                             <p class="card-text mb-2">
    //                                 <span class="fw-semibold">Описание</span>: %s
    //                             </p>
    //                         </div>
    //                     </div>
    //                 </div>', 
    //                 $item['id_application'], 
    //                 $item['status'], 
    //                 $item['sname'], 
    //                 $item['date'], 
    //                 $item['time'], 
    //                 $item['pname'], 
    //                 ($item['id_service'] == "0") ? $item['description'] : $item['sname']
    //             );
    //         }
            
    
    //         $data .= "</div>";
    //     }
    
    //     return $data;
    // }
    

// Реализация вывода с разделением по статусам

    function fnOutCardProfile($login){
        global $connect;
        $sql = "SELECT * FROM `user` WHERE `login` = '{$login}'";
        $result = $connect->query($sql);
        $user = $result->fetch_assoc();
        $sql = "SELECT `id_application`, `status`,`status_info`, `date`, `time`,
               `pay`.`name` AS `pname`, `service`.`name` AS `sname`, `code`,
                `description`, `service`.`id_service` FROM `application` INNER JOIN
                `service` ON `application`.`id_service` = `service`.`id_service`
                INNER JOIN `pay` ON `application`.`id_pay` = `pay`.`id_pay`
                INNER JOIN `status` ON `application`.`id_status` =   
                `status`.`id_status` WHERE `application`.`id_user` = 
                {$user['id_user']} ORDER BY `id_application` DESC";
        $result = $connect->query($sql);
        if(!$result->num_rows){
            $data = "<h4 class='display-6 text-center'>Заявок не найдено<h4>";
        }else{
            $data = "<div class='cards my-4 row row-cols-1 row-cols-md-3 g-4'>";
            
            foreach($result as $item){
                if($item['code'] == "new"){
                     $data .= sprintf('
                     <div class="col">
                         <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title fs-3">Заявка №%s</h5>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Статус заявки</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Категория</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Дата</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Время</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Способ оплаты</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Описание</span>: %s
                                </p>
                            </div>
                         </div>
                     </div>', 
                     $item['id_application'], 
                     $item['status'], 
                     $item['sname'], 
                     $item['date'], 
                     $item['time'], 
                     $item['pname'], 
                     ($item['id_service'] == "0") ? $item['description'] : $item['sname']);
                 }elseif($item['code'] == "canceled"){
                     $data .= sprintf('
                     <div class="col">
                         <div class="card mb-3 text-body-tertiary">
                            <div class="card-body">
                                <h5 class="card-title fs-3">Заявка №%s</h5>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Статус заявки</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Причина отмены</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Категория</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Дата</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Время</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Способ оплаты</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Описание</span>: %s
                                </p>
                            </div>
                         </div>
                     </div>', 
                     $item['id_application'], 
                     $item['status'], 
                     $item['status_info'],
                     $item['sname'], 
                     $item['date'], 
                     $item['time'], 
                     $item['pname'], 
                     ($item['id_service'] == "0") ? $item['description'] : $item['sname']);
                 }elseif($item['code'] == "confirmed"){
                     $data .= sprintf('
                     <div class="col">
                         <div class="card mb-3 text-success">
                            <div class="card-body">
                                <h5 class="card-title fs-3">Заявка №%s</h5>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Статус заявки</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Категория</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Дата</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Время</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Способ оплаты</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Описание</span>: %s
                                </p>
                            </div>
                         </div>
                     </div>', 
                     $item['id_application'], 
                     $item['status'], 
                     $item['sname'], 
                     $item['date'], 
                     $item['time'], 
                     $item['pname'], 
                     ($item['id_service'] == "0") ? $item['description'] : $item['sname']);
                 }elseif($item['code'] == "process"){
                     $data .= sprintf('
                     <div class="col">
                         <div class="card mb-3 text-info-emphasis">
                            <div class="card-body">
                                <h5 class="card-title fs-3">Заявка №%s</h5>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Статус заявки</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Категория</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Дата</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Время</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Способ оплаты</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Описание</span>: %s
                                </p>
                            </div>
                         </div>
                     </div>', 
                     $item['id_application'], 
                     $item['status'], 
                     $item['sname'], 
                     $item['date'], 
                     $item['time'], 
                     $item['pname'], 
                     ($item['id_service'] == "0") ? $item['description'] : $item['sname']);
                 }
             }     
    
            $data .= "</div>";
        }
    
        return $data;
    }


    function fnOutCardAdmin(){
        global $connect;

        $sql = "SELECT `id_application`, `user`.`name` AS `u_name`, `surname`, `patronymic`, `status`,`status_info`, `date`, `time`,`address`, `pay`.`name` AS `pname`, `service`.`name` AS `sname`, `code`, `description`, `service`.`id_service`, `application`.`phone`AS `a_phone` FROM `application` 
                INNER JOIN `service` ON `application`.`id_service` = `service`.`id_service` 
                INNER JOIN `pay` ON `application`.`id_pay` = `pay`.`id_pay` 
                INNER JOIN `status` ON `application`.`id_status` = `status`.`id_status` 
                INNER JOIN `user` ON `application`.`id_user` = `user`.`id_user` 
                ORDER BY `id_application` DESC";
        
        $result = $connect->query($sql);
        if(!$result->num_rows){
            $data = "<h4 class='display-6 text-center'>Заявок не найдено<h4>";
        }else{
            $data = "<div class='cards my-4 row row-cols-1 row-cols-md-3 g-4'>";
            
            foreach($result as $item){
                if($item['code'] == "new"){
                     $data .= sprintf('
                     <div class="col">
                         <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title fs-3">Заявка №%s</h5>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Фамилия</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Имя</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Отчество</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Адрес</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Телефон</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Статус заявки</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Категория</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Дата</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Время</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Способ оплаты</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Описание</span>: %s
                                </p>
                            </div>
                            <div class="buttons d-flex justify-content-between flex-wrap">
                                <a href="../admin/controllers/update_applicate.php?id=%s&type=process" 
                                class="btn btn-outline-warning p-2 w-100 rounded-3 shadow-sm fw-bold fs-6 my-2"     
                                title="Изменение статуса заявки на \'В работе\'">В работе</a>
                                <a href="../admin/controllers/update_applicate.php?id=%s&type=confirmed" 
                                class="btn btn-outline-success p-2 w-100 rounded-3 shadow-sm fw-bold fs-6 my-2"
                                title="Изменение статуса заявки на \'Выполнено\'">Выполнено</a>
                            
                                <form action="../admin/controllers/update_applicate.php" method="GET">
                                    <input type="hidden" name="id" value="%s">
                                    <input type="hidden" name="type" value="canceled">
                                    <textarea class="form-control fs-3 rounded-5 shadow-sm" rows="6" name="info" 
                                            required placeholder="Причина отмены"></textarea>
                                    <button class="btn btn-outline-danger p-2 w-100 rounded-3 shadow-sm fw-bold fs-6 my-2"  title="Изменение статуса заявки на \'Отменено\'">Отменить</button>
                                </form>
                            </div>
                         </div>
                     </div>', 
                     $item['id_application'],
                     $item['surname'], 
                     $item['u_name'], 
                     $item['patronymic'], 
                     $item['address'], 
                     $item['a_phone'],                   
                     $item['status'], 
                     $item['sname'], 
                     $item['date'], 
                     $item['time'], 
                     $item['pname'], 
                     ($item['id_service'] == "0") ? $item['description'] : $item['sname'],$item['id_application'], 
                     $item['id_application'], 
                     $item['id_application']); 
                 }elseif($item['code'] == "canceled"){
                     $data .= sprintf('
                     <div class="col">
                         <div class="card mb-3 text-body-tertiary">
                            <div class="card-body">
                                <h5 class="card-title fs-3">Заявка №%s</h5>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Фамилия</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Имя</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Отчество</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Адрес</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Телефон</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Статус заявки</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Причина отмены</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Категория</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Дата</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Время</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Способ оплаты</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Описание</span>: %s
                                </p>
                            </div>
                         </div>
                     </div>', 
                     $item['id_application'], 
                     $item['surname'], 
                     $item['u_name'], 
                     $item['patronymic'], 
                     $item['address'], 
                     $item['a_phone'],                  
                     $item['status'], 
                     $item['status_info'],
                     $item['sname'], 
                     $item['date'], 
                     $item['time'], 
                     $item['pname'], 
                     ($item['id_service'] == "0") ? $item['description'] : $item['sname']);
                 }elseif($item['code'] == "confirmed"){
                     $data .= sprintf('
                     <div class="col">
                         <div class="card mb-3 text-success">
                            <div class="card-body">
                                <h5 class="card-title fs-3">Заявка №%s</h5>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Фамилия</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Имя</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Отчество</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Адрес</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Телефон</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Статус заявки</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Категория</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Дата</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Время</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Способ оплаты</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Описание</span>: %s
                                </p>
                            </div>
                         </div>
                     </div>', 
                     $item['id_application'],
                     $item['surname'], 
                     $item['u_name'], 
                     $item['patronymic'], 
                     $item['address'], 
                     $item['a_phone'],                  
                     $item['status'], 
                     $item['sname'], 
                     $item['date'], 
                     $item['time'], 
                     $item['pname'], 
                     ($item['id_service'] == "0") ? $item['description'] : $item['sname']);
                 }elseif($item['code'] == "process"){
                     $data .= sprintf('
                     <div class="col">
                         <div class="card mb-3 text-info-emphasis">
                            <div class="card-body">
                                <h5 class="card-title fs-3">Заявка №%s</h5>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Фамилия</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Имя</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Отчество</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Адрес</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Телефон</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Статус заявки</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Категория</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Дата</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Время</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Способ оплаты</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Описание</span>: %s
                                </p>
                            </div>
                         </div>
                     </div>', 
                     $item['id_application'],
                     $item['surname'], 
                     $item['u_name'], 
                     $item['patronymic'], 
                     $item['address'], 
                     $item['a_phone'],                   
                     $item['status'], 
                     $item['sname'], 
                     $item['date'], 
                     $item['time'], 
                     $item['pname'], 
                     ($item['id_service'] == "0") ? $item['description'] : $item['sname']);
                 }
             }     
    
            $data .= "</div>";
        }
    
        return $data;
    }


    function fnOutCardAdminStatus($code){
        global $connect;
        $sql = "SELECT `id_status` FROM `status` WHERE `code` = '{$code}'";
        $result = $connect->query($sql);
        $status = $result->fetch_assoc();
        $sql = "SELECT `id_application`, `user`.`name` AS `u_name`, `surname`, `patronymic`, `status`,`status_info`, `date`, `time`,`address`, `pay`.`name` AS `pname`, `service`.`name` AS `sname`, `code`, `description`, `service`.`id_service`, `application`.`phone`AS `a_phone` FROM `application` INNER JOIN `service` ON `application`.`id_service` = `service`.`id_service` INNER JOIN `pay` ON `application`.`id_pay` = `pay`.`id_pay` INNER JOIN `status` ON `application`.`id_status` = `status`.`id_status` INNER JOIN `user` ON `application`.`id_user` = `user`.`id_user` WHERE `application`.`id_status` = '{$status['id_status']}' ORDER BY `id_application` DESC";
        $result = $connect->query($sql);
        if(!$result->num_rows){
            if($code == "new"){
                $data = "<h4 class='display-6 text-center'>Новых заявок не найдено<h4>";
            }elseif($code == "process"){
                $data = "<h4 class='display-6 text-center'>Заявок в процессе не найдено<h4>";
            }elseif($code == "canceled"){
                $data = "<h4 class='display-6 text-center'>Отменных заявок не найдено<h4>";
            }elseif($code == "confirmed"){
                $data = "<h4 class='display-6 text-center'>Выполненных заявок не найдено<h4>";
            }
        }else{
            $data = "<div class='cards row row-cols-1 row-cols-md-3 g-4'>";
            foreach($result as $item){
                if($item['code'] == "new"){
                     $data .= sprintf('
                     <div class="col">
                         <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title fs-3">Заявка №%s</h5>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Фамилия</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Имя</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Отчество</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Адрес</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Телефон</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Статус заявки</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Категория</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Дата</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Время</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Способ оплаты</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Описание</span>: %s
                                </p>
                            </div>
                            <div class="buttons d-flex justify-content-between flex-wrap">
                                <a href="../admin/controllers/update_applicate.php?id=%s&type=process" 
                                class="btn btn-outline-warning p-2 w-100 rounded-3 shadow-sm fw-bold fs-6 my-2"     
                                title="Изменение статуса заявки на \'В работе\'">В работе</a>
                                <a href="../admin/controllers/update_applicate.php?id=%s&type=confirmed" 
                                class="btn btn-outline-success p-2 w-100 rounded-3 shadow-sm fw-bold fs-6 my-2"
                                title="Изменение статуса заявки на \'Выполнено\'">Выполнено</a>
                            
                                <form action="../admin/controllers/update_applicate.php" method="GET">
                                    <input type="hidden" name="id" value="%s">
                                    <input type="hidden" name="type" value="canceled">
                                    <textarea class="form-control fs-3 rounded-5 shadow-sm" rows="6" name="info" 
                                            required placeholder="Причина отмены"></textarea>
                                    <button class="btn btn-outline-danger p-2 w-100 rounded-3 shadow-sm fw-bold fs-6 my-2"  title="Изменение статуса заявки на \'Отменено\'">Отменить</button>
                                </form>
                            </div>
                         </div>
                     </div>', 
                     $item['id_application'],
                     $item['surname'], 
                     $item['u_name'], 
                     $item['patronymic'], 
                     $item['address'], 
                     $item['a_phone'],                   
                     $item['status'], 
                     $item['sname'], 
                     $item['date'], 
                     $item['time'], 
                     $item['pname'], 
                     ($item['id_service'] == "0") ? $item['description'] : $item['sname'],$item['id_application'], 
                     $item['id_application'], 
                     $item['id_application']); 
                 }elseif($item['code'] == "canceled"){
                     $data .= sprintf('
                     <div class="col">
                         <div class="card mb-3 text-body-tertiary">
                            <div class="card-body">
                                <h5 class="card-title fs-3">Заявка №%s</h5>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Фамилия</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Имя</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Отчество</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Адрес</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Телефон</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Статус заявки</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Причина отмены</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Категория</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Дата</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Время</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Способ оплаты</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Описание</span>: %s
                                </p>
                            </div>
                         </div>
                     </div>', 
                     $item['id_application'], 
                     $item['surname'], 
                     $item['u_name'], 
                     $item['patronymic'], 
                     $item['address'], 
                     $item['a_phone'],                  
                     $item['status'], 
                     $item['status_info'],
                     $item['sname'], 
                     $item['date'], 
                     $item['time'], 
                     $item['pname'], 
                     ($item['id_service'] == "0") ? $item['description'] : $item['sname']);
                 }elseif($item['code'] == "confirmed"){
                     $data .= sprintf('
                     <div class="col">
                         <div class="card mb-3 text-success">
                            <div class="card-body">
                                <h5 class="card-title fs-3">Заявка №%s</h5>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Фамилия</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Имя</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Отчество</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Адрес</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Телефон</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Статус заявки</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Категория</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Дата</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Время</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Способ оплаты</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Описание</span>: %s
                                </p>
                            </div>
                         </div>
                     </div>', 
                     $item['id_application'],
                     $item['surname'], 
                     $item['u_name'], 
                     $item['patronymic'], 
                     $item['address'], 
                     $item['a_phone'],                  
                     $item['status'], 
                     $item['sname'], 
                     $item['date'], 
                     $item['time'], 
                     $item['pname'], 
                     ($item['id_service'] == "0") ? $item['description'] : $item['sname']);
                 }elseif($item['code'] == "process"){
                     $data .= sprintf('
                     <div class="col">
                         <div class="card mb-3 text-info-emphasis">
                            <div class="card-body">
                                <h5 class="card-title fs-3">Заявка №%s</h5>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Фамилия</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Имя</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Отчество</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Адрес</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Телефон</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Статус заявки</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Категория</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Дата</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Время</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Способ оплаты</span>: %s
                                </p>
                                <p class="card-text mb-2">
                                    <span class="fw-semibold">Описание</span>: %s
                                </p>
                            </div>
                         </div>
                     </div>', 
                     $item['id_application'],
                     $item['surname'], 
                     $item['u_name'], 
                     $item['patronymic'], 
                     $item['address'], 
                     $item['a_phone'],                   
                     $item['status'], 
                     $item['sname'], 
                     $item['date'], 
                     $item['time'], 
                     $item['pname'], 
                     ($item['id_service'] == "0") ? $item['description'] : $item['sname']);
                 }
             }     
            $data .= "</div>";
        }
        return $data;
    }
    