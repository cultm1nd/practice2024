<?php
    session_start();
    $menu = "";
    if(isset($_SESSION['login'])){
        if($_SESSION['role'] == "admin"){
            $menu .= '<li class="nav-item">
                        <a class="nav-link" href="/admin/">Админ Панель</a>
                      </li>';
        }
        $menu .= '<li class="nav-item">
                    <a class="nav-link" href="/profile/">Личный кабинет</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="/admin/controllers/logout.php">
                      Выйти </a>
                  </li>';
    }else{
        $menu = '<li class="nav-item">
                   <a class="nav-link" href="/">Вход</a>
                 </li>
                 <li class="nav-item">
                   <a class="nav-link" href="/register/">Регистрация</a>
                 </li>';
    }
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мой Не Сам</title>
    <link rel="stylesheet" href="/assets/bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/style/style.css">
</head>
<body>
<body>
    <main>
        <header>
            <nav class="navbar navbar-expand-lg bg-success navbar-dark">
                <div class="container-fluid">
                <a class="navbar-brand" href="/">
                    <img src="/assets/media/logo.png" alt="Logo" width="50" height="50"
                        class="d-inline-block">
                    Мой Не Сам
                </a>

                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <?=$menu?>
                    </ul>
                    <form class="d-flex" role="search">
                        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Поиск</button>
                    </form>
                    </div>
                </div>
            </nav>
        </header>
