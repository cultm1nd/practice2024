<?php
    include ("../include/header.php");
    include ("../function/function.php");

    if(!isset($_SESSION['login'])){
        header("Location: /");
        exit;
    }
    

?>
    <!--здесь будет контент-->

    <section>
    <div class="container py-3">
        <h3 class="display-3 text-center">Личный кабинет</h3>
        
        <?php 
            echo fnOutCardProfile($_SESSION['login']);
        ?> 

        <a href="/application/" class="btn btn-success my-3 w-100 shadow-sm p-3 fs-3 rounded-pill shadow-sm fw-bold w-100 fs-3 my-3">
            Сформировать заявку
        </a>


    </div>
</section>


<?php
    include ("../include/footer.php");
?>

