<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\Product;

class OrderController extends Controller
{
    //вывод
    public function index()
    {
        $orders = Order::with('product')->get();
        return view('orders.index', compact('orders'));
    }
    //проверка или создание
    public function store(Request $request)
    {
        $product = Product::findOrFail($request->product_id);

        if (!$product->isAvailable()) {
            return back()->with('error', 'Product is not available');
        }

        Order::create([
            'product_id' => $product->id,
            'quantity' => 1,
        ]);

        $product->decrement('quantity');

        return back()->with('success', 'Order created successfully');
    }
}
