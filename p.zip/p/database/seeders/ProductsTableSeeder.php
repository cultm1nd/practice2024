<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Product;
class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $products=[
            [
                'name'=>'Product 1',
                'price'=>100,
                'description'=>'Product 1 description',
                'image'=>'product1.jpg',
                'quantity'=>'10',
            ],
            [
                'name'=>'Product 2',
                'price'=>1000,
                'description'=>'Product 2 description',
                'image'=>'product2.jpg',
                'quantity'=>'1',
            ],
            [
                'name'=>'Product 3',
                'price'=>5000,
                'description'=>'Product 3 description',
                'image'=>'product3.jpg',
                'quantity'=>'0',
            ],
        ];
        foreach($products as $product){
            Product::create($product);
        }
    }
}
