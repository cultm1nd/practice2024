@extends('layouts.app')

@section('content')
    <h1 class="mb-4">Мои заказы</h1>
    
    @if($orders->isEmpty())
        <div class="alert alert-info">
            У вас пока нет заказов
        </div>
    @else
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Товар</th>
                        <th>Изображение</th>
                        <th>Цена</th>
                        <th>Количество</th>
                        <th>Статус</th>
                        <th>Дата заказа</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($orders as $order)
                        <tr>
                            <td>{{ $order->product->name }}</td>
                            <td>
                                <img src="{{ asset('storage/' . $order->product->image) }}" width="50" alt="{{ $order->product->name }}">
                            </td>
                            <td>{{ $order->product->price }} руб.</td>
                            <td>{{ $order->quantity }}</td>
                            <td>
                                <span class="badge badge-{{ $order->status === 'pending' ? 'warning' : 'success' }}">
                                    {{ $order->status === 'pending' ? 'В обработке' : 'Завершен' }}
                                </span>
                            </td>
                            <td>{{ $order->created_at->format('d.m.Y H:i') }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif
    
    <a href="{{ route('products.index') }}" class="btn btn-primary">Вернуться в каталог</a>
@endsection