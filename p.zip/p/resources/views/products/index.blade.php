@extends('layouts.app')

@section('content')
    <h1 class="mb-4">Каталог товаров</h1>
    
    <div class="row">
        @foreach($products as $product)
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="{{ asset('storage/' . $product->image) }}" class="card-img-top" alt="{{ $product->name }}" style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">{{ $product->name }}</h5>
                        <p class="card-text">{{ Str::limit($product->description, 100) }}</p>
                        <p class="card-text"><strong>Цена: {{ $product->price }} руб.</strong></p>
                        <p class="card-text">
                            @if($product->isAvailable())
                                <span class="badge badge-success">В наличии</span>
                            @else
                                <span class="badge badge-danger">Нет в наличии</span>
                            @endif
                        </p>
                    </div>
                    <div class="card-footer">
                        <a href="{{ route('products.show', $product) }}" class="btn btn-primary">Подробнее</a>
                        @if($product->isAvailable())
                            <form action="{{ route('orders.store', $product) }}" method="POST" class="d-inline">
                                @csrf
                                <button type="submit" class="btn btn-success">Заказать</button>
                            </form>
                        @else
                            <button class="btn btn-secondary" disabled>Заказать</button>
                        @endif
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endsection