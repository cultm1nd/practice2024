@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-6">
            <img src="{{ asset('storage/' . $product->image) }}" class="img-fluid" alt="{{ $product->name }}">
        </div>
        <div class="col-md-6">
            <h1>{{ $product->name }}</h1>
            <p class="lead">{{ $product->price }} руб.</p>
            <p>{{ $product->description }}</p>
            <p>
                @if($product->isAvailable())
                    <span class="badge badge-success">В наличии</span>
                @else
                    <span class="badge badge-danger">Нет в наличии</span>
                @endif
            </p>
            
            @if($product->isAvailable())
                <form action="{{ route('orders.store', $product) }}" method="POST">
                    @csrf
                    <button type="submit" class="btn btn-success btn-lg">Заказать</button>
                </form>
            @else
                <button class="btn btn-secondary btn-lg" disabled>Заказать</button>
            @endif
            
            <a href="{{ route('products.index') }}" class="btn btn-primary mt-3">Назад в каталог</a>
        </div>
    </div>
@endsection