

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Мои заказы</h1>
    
    <?php if($orders->isEmpty()): ?>
        <div class="alert alert-info">
            У вас пока нет заказов
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Товар</th>
                        <th>Изображение</th>
                        <th>Цена</th>
                        <th>Количество</th>
                        <th>Статус</th>
                        <th>Дата заказа</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($order->product->name); ?></td>
                            <td>
                                <img src="<?php echo e(asset('storage/' . $order->product->image)); ?>" width="50" alt="<?php echo e($order->product->name); ?>">
                            </td>
                            <td><?php echo e($order->product->price); ?> руб.</td>
                            <td><?php echo e($order->quantity); ?></td>
                            <td>
                                <span class="badge badge-<?php echo e($order->status === 'pending' ? 'warning' : 'success'); ?>">
                                    <?php echo e($order->status === 'pending' ? 'В обработке' : 'Завершен'); ?>

                                </span>
                            </td>
                            <td><?php echo e($order->created_at->format('d.m.Y H:i')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
    
    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">Вернуться в каталог</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\p\resources\views/orders/index.blade.php ENDPATH**/ ?>