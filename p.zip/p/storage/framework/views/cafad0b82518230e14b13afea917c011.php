

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="img-fluid" alt="<?php echo e($product->name); ?>">
        </div>
        <div class="col-md-6">
            <h1><?php echo e($product->name); ?></h1>
            <p class="lead"><?php echo e($product->price); ?> руб.</p>
            <p><?php echo e($product->description); ?></p>
            <p>
                <?php if($product->isAvailable()): ?>
                    <span class="badge badge-success">В наличии</span>
                <?php else: ?>
                    <span class="badge badge-danger">Нет в наличии</span>
                <?php endif; ?>
            </p>
            
            <?php if($product->isAvailable()): ?>
                <form action="<?php echo e(route('orders.store', $product)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-success btn-lg">Заказать</button>
                </form>
            <?php else: ?>
                <button class="btn btn-secondary btn-lg" disabled>Заказать</button>
            <?php endif; ?>
            
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary mt-3">Назад в каталог</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\p\resources\views/products/show.blade.php ENDPATH**/ ?>