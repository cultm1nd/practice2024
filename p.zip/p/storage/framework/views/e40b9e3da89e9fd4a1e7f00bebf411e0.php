

<?php $__env->startSection('content'); ?>
<h1 class="mb-4">Каталог товаров</h1>

<div class="row">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <img src="<?php echo e(asset('img/' . $product->image)); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>" style="height: 200px; object-fit: cover;">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($product->name); ?></h5>
                <p class="card-text"><?php echo e(Str::limit($product->description, 100)); ?></p>
                <p class="card-text"><strong>Цена: <?php echo e($product->price); ?> руб.</strong></p>
                <p class="card-text">
                    <?php if($product->isAvailable()): ?>
                    <span class="badge badge-success">В наличии</span>
                    <?php else: ?>
                    <span class="badge badge-danger">Нет в наличии</span>
                    <?php endif; ?>
                </p>
            </div>
            <div class="card-footer">
                <a href="<?php echo e(route('products.show', $product)); ?>" class="btn btn-primary">Подробнее</a>
                <?php if($product->isAvailable()): ?>
                <form action="<?php echo e(route('orders.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                    <button type="submit" class="btn btn-success">Заказать</button>
                </form>
                <?php else: ?>
                <button class="btn btn-secondary" disabled>Заказать</button>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\p\resources\views/products/index.blade.php ENDPATH**/ ?>