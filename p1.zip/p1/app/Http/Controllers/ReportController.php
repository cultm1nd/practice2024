<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Report;

class ReportController extends Controller
{
    public function index()
    {
        $reports = Report::where('user_id', auth()->id())->paginate(10);
        return view('reports.index', compact('reports'));
    }

    public function create()
    {
        return view('reports.create');
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'car_number' => 'required|string|max:20',
            'description' => 'required|string',
        ]);

        $report = Report::create([
            'user_id' => auth()->id(),
            'car_number' => $validatedData['car_number'],
            'description' => $validatedData['description'],
            'status' => 'new', 

        ]);

        session()->flash('success', 'Заявление успешно зарегестрировано');
        return redirect()->route('reports');
    }

    public function show($id)
    {
        $report = Report::findOrFail($id);
        return view('reports.show', compact('report'));
    }
    public function changeStatus(Request $request, $id)
    {
        $report = Report::findOrFail($id);

        if ($request->input('status') === 'confirmed') {
            $report->changeStatus('confirmed');
        } elseif ($request->input('status') === 'rejected') {
            $report->changeStatus('rejected');
        } else {
            abort(400, 'Неверный статус');
        }

        session()->flash('success', 'Статус успешно обновлен');
        return redirect()->back();
    }
}
