<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    use HasFactory;

    protected $fillable = ['id', 'user_id', 'car_number', 'description', 'status'];

    public function changeStatus($newStatus)
    {
        if ($this->status === 'new') {
            $this->update(['status' => $newStatus]);
        } else {
            throw new \Exception('Can only change status of new reports');
        }
    }
}