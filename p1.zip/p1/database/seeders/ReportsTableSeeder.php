<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Report;

class ReportsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Report::create([
            'user_id' => 1,
            'car_number' => 'ABC123',
            'description' => 'Test report description',
            'status' => 'new',
        ]);
    }
}
