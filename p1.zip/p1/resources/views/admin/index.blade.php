@include('blocks.headerAdmin')

<table class="table table-striped">
    <thead>
        <tr>
            <th>№</th>
            <th>Гос номер машины</th>
            <th>Описание</th>
            <th>Статус</th>
            <th>Действие</th>
        </tr>
    </thead>
    <tbody>
         @foreach($reports as $report)
            <tr>
                <td>{{ $report->id }}</td>
                <td>{{ $report->car_number }}</td>
                <td>{{ Str::limit($report->description, 50) }}</td>
                <td>{{ $report->status }}</td>
             

                <td>
                    @if($report->status === 'new')
                        <form action="{{ route('updateStatus') }}" method="POST">
                            @csrf
                            <input type="hidden" name="id" value="{{ $report->id }}">
                            <button type="submit" name="status" value="confirmed">Подтвердить</button>
                            <button type="submit" name="status" value="rejected">Отказать</button>
                        </form>
                    @else
                        <p>Статус уже изменен</p>
                    @endif
                </td>
            </tr>
        @endforeach
    </tbody>
</table>
