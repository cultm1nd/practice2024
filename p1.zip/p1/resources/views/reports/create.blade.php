@include('blocks.header')


<h1>Leave New Report</h1>

<form method="POST" action="{{ route('reports.store') }}">
    @csrf

    <div class="form-group">
        <label for="car_number">Государственный регистрационный номер автомобиля </label>
        <input type="text" class="form-control @error('car_number') is-invalid @enderror" id="car_number" name="car_number" value="{{ old('car_number') }}" required>
    </div>

    <div class="form-group">
        <label for="description">Описание нарушения</label>
        <textarea class="form-control @error('description') is-invalid @enderror" id="description" name="description" required>{{ old('description') }}</textarea>
    </div>
    <input type="hidden" id="user_id" name="user_id" value="{{auth()->id()}}">

    <button type="submit" class="btn btn-primary">Создать</button>
</form>
<p>{{auth()->id()}}</p>
@error('car_number')
    <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
    </span>
@enderror

@error('description')
    <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
    </span>
@enderror
