@include('blocks.header')

<h1>Мои заявления</h1>

@if (session()->has('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

<a href="{{ route('reports.create') }}" class="btn btn-primary">Оставить новое заявление</a>

<table class="table table-striped">
    <thead>
        <tr>
            <th>№</th>
            <th>Номер машины</th>
            <th>Описание</th>
            <th>Статус</th>
            <th></th>
        </tr>
    </thead>
    <tbody id="report-table-body">
         @foreach($reports as $index => $report)
            <tr class="animate-row" data-index="{{ $index }}">
                <td>{{ $report->id }}</td>
                <td>{{ $report->car_number }}</td>
                <td>{{ Str::limit($report->description, 50) }}</td>
                <td>{{ $report->status }}</td>
 
                <td>
                    <a href="{{ route('reports.show', $report->id) }}" class="btn btn-sm btn-primary">Посмотреть</a>
                    @if (Auth::user()->role == 1)

                    @if($report->status === 'new')
                        <form action="{{ route('updateStatus') }}" method="POST" class="status-form">
                            @csrf
                            <input type="hidden" name="id" value="{{ $report->id }}">
                           
                            <button type="submit" class="btn btn-secondary" name="status" value="confirmed">Подтвердить</button>
                            <button type="submit" class="btn btn-primary" name="status" value="rejected">Отказать</button>
                        </form>
                    @elseif($report->status === 'confirmed' || $report->status === 'rejected')
                        <p>Статус уже изменен</p>
                    @endif
                    @endif

                </td>
            </tr>
        @endforeach
    </tbody>
</table>

{{ $reports->links() }}

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    const tbody = $('#report-table-body');
    
    // Создаем массив с данными
    const reportsData = Array.from(tbody.find('.animate-row')).map(row => ({
        index: parseInt(row.getAttribute('data-index')),
        ...Array.from(row.children).reduce((acc, cell) => ({...acc, [cell.tagName.toLowerCase()]: cell.textContent}), {})
    }));

    // Сортируем данные по индексу
    reportsData.sort((a, b) => a.index - b.index);

    // Функция для анимации появления строки
    function animateRow(index) {
        const row = tbody.find(`.animate-row[data-index="${index}"]`);
        row.css({
            opacity: 0,
            transform: 'translateY(-30px)'
        });
        
        setTimeout(() => {
            row.css({
                opacity: 1,
                transform: 'translateY(0)'
            });
        }, 50 * index);
    }

    // Анимируем каждую строку
    reportsData.forEach(animateRow);
});
</script>
