@include('blocks.header')


<h1>Детали заявления</h1>

<p><strong>№:</strong> {{ $report->id }}</p>
<p><strong>Государственный регистрационный номер автомобиля:</strong> {{ $report->car_number }}</p>
<p><strong>Описание нарушения:</strong> {{ $report->description }}</p>
<p><strong>Статус:</strong> {{ $report->status }}</p>

<a href="{{ route('reports') }}" class="btn btn-secondary">Назад</a>
