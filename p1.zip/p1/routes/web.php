<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\AdminController; 
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('home');
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Дополнительные маршруты для регистрации
Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);

 
 
// Route::get('/statements', [ReportController::class, 'index'])->name('statements');
// Route::get('/statement/create', [ReportController::class, 'create'])->name('statement.create');
// Route::post('/statement', [ReportController::class, 'store'])->name('statement.store');


Route::get('/reports', [ReportController::class, 'index'])->name('reports');
Route::get('/reports/create', [ReportController::class, 'create'])->name('reports.create');
Route::post('/report', [ReportController::class, 'store'])->name('reports.store');
Route::get('/reports/{id}', [ReportController::class, 'show'])->name('reports.show');


Route::get('/admin', [AdminController::class, 'index'])->middleware('auth')->name('admin');



 Route::post('/admin/status-update', [AdminController::class, 'updateStatus'])->name('updateStatus');
 