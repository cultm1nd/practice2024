<?php echo $__env->make('blocks.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<h1>Детали заявления</h1>

<p><strong>ID:</strong> <?php echo e($report->id); ?></p>
<p><strong>Государственный регистрационный номер автомобиля:</strong> <?php echo e($report->car_number); ?></p>
<p><strong>Описание нарушения:</strong> <?php echo e($report->description); ?></p>
<p><strong>Статус:</strong> <?php echo e($report->status); ?></p>

<a href="<?php echo e(route('reports')); ?>" class="btn btn-secondary">Back to Reports</a>
<?php /**PATH C:\OSPanel\domains\pract1\resources\views/reports/show.blade.php ENDPATH**/ ?>