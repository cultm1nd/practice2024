<?php echo $__env->make('blocks.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4">
            <div class="card bg-white shadow-lg rounded-lg overflow-hidden">
                <div class="card-header bg-gray-100 p-4">
                    <h2 class="text-center">Авторизация</h2>
                </div>
                <div class="card-body p-5">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                      <?php echo csrf_field(); ?>
                      <div class="mb-3">
                        <label for="login" class="form-label">Логин</label>
                        <input type="login" name="login" id="login" class="form-control" required>
                      </div>

                      <div class="mb-3">
                        <label for="password" class="form-label">Пароль</label>
                        <input type="password" name="password" id="password" class="form-control" required>
                      </div>

                      <button type="submit" class="btn btn-primary w-100 mt-3">Войти</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if($errors->any()): ?>
  <div class="alert alert-danger mt-4">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>
<?php /**PATH C:\OSPanel\domains\borovinskikh\p1\resources\views/auth/login.blade.php ENDPATH**/ ?>