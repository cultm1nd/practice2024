<?php echo $__env->make('blocks.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1>Мои отчеты</h1>

<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<a href="<?php echo e(route('reports.create')); ?>" class="btn btn-primary">Оставить новый отчет</a>

<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Car Number</th>
            <th>Description</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody id="report-table-body">
         <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="animate-row" data-index="<?php echo e($index); ?>">
                <td><?php echo e($report->id); ?></td>
                <td><?php echo e($report->car_number); ?></td>
                <td><?php echo e(Str::limit($report->description, 50)); ?></td>
                <td><?php echo e($report->status); ?></td>
 
                <td>
                    <a href="<?php echo e(route('reports.show', $report->id)); ?>" class="btn btn-sm btn-primary">Посмотреть</a>
                    <?php if(Auth::user()->role == 1): ?>

                    <?php if($report->status === 'new'): ?>
                        <form action="<?php echo e(route('updateStatus')); ?>" method="POST" class="status-form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($report->id); ?>">
                           
                            <button type="submit" class="btn btn-secondary" name="status" value="confirmed">подтвердить</button>
                            <button type="submit" class="btn btn-primary" name="status" value="rejected">отказать</button>
                        </form>
                    <?php elseif($report->status === 'confirmed' || $report->status === 'rejected'): ?>
                        <p>Статус уже изменен</p>
                    <?php endif; ?>
                    <?php endif; ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($reports->links()); ?>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    const tbody = $('#report-table-body');
    
    // Создаем массив с данными
    const reportsData = Array.from(tbody.find('.animate-row')).map(row => ({
        index: parseInt(row.getAttribute('data-index')),
        ...Array.from(row.children).reduce((acc, cell) => ({...acc, [cell.tagName.toLowerCase()]: cell.textContent}), {})
    }));

    // Сортируем данные по индексу
    reportsData.sort((a, b) => a.index - b.index);

    // Функция для анимации появления строки
    function animateRow(index) {
        const row = tbody.find(`.animate-row[data-index="${index}"]`);
        row.css({
            opacity: 0,
            transform: 'translateY(-30px)'
        });
        
        setTimeout(() => {
            row.css({
                opacity: 1,
                transform: 'translateY(0)'
            });
        }, 50 * index);
    }

    // Анимируем каждую строку
    reportsData.forEach(animateRow);
});
</script>
<?php /**PATH C:\OSPanel\domains\borovinskikh\p\resources\views/reports/index.blade.php ENDPATH**/ ?>