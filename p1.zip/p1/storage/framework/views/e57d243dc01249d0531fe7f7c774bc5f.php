<?php echo $__env->make('blocks.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<table class="table table-striped">
    <thead>
        <tr>
            <th>№</th>
            <th>Гос номер машины</th>
            <th>Описание</th>
            <th>Статус</th>
            <th>Действие</th>
        </tr>
    </thead>
    <tbody>
         <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($report->id); ?></td>
                <td><?php echo e($report->car_number); ?></td>
                <td><?php echo e(Str::limit($report->description, 50)); ?></td>
                <td><?php echo e($report->status); ?></td>
             

                <td>
                    <?php if($report->status === 'new'): ?>
                        <form action="<?php echo e(route('updateStatus')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($report->id); ?>">
                            <button type="submit" name="status" value="confirmed">Подтвердить</button>
                            <button type="submit" name="status" value="rejected">Отказать</button>
                        </form>
                    <?php else: ?>
                        <p>Статус уже изменен</p>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\OSPanel\domains\borovinskikh\p1\resources\views/admin/index.blade.php ENDPATH**/ ?>