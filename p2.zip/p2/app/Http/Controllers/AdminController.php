<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\Order;

class AdminController extends Controller
{ 
    public function index(Request $request)
    {
        // Получаем статус из запроса (если он есть)
        $status = $request->input('status');
        // Получаем все заказы с загруженными пользователями и продуктами
        $orders = Order::with(['user', 'product']);
        // Если статус выбран, фильтруем заказы по статусу
        if ($status) {
            $orders->where('status', $status);
        }
        // Получаем заказы
        $orders = $orders->get();
        return view('adminOrder', compact('orders', 'status'));
    }
    
        public function update(Request $request, Order $order)
        {
            if ($order->status !== 'Новый') {
                return redirect()->back()->withErrors(['status' => 'Статус заказа можно изменить только для новых заказов.']);
            }
            $request->validate([
                'status' => 'required|string|in: Новый,Подтвержден,Отменен',
            ]);
    
            // Обновляем статус заказа
            $order->status = $request->status;
            $order->save();
    
            return redirect()->route('admin.orders.index')->with('success', 'Статус заказа успешно обновлен.');
        }

}
