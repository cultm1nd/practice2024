<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Product;
use App\Models\Order;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    //заказы текущего юзера
   public function orders()
    {
        $orders = Order::with('product')->where('user_id', auth()->id())->get();
        return view('orders', compact('orders'));
    }
    public function create(){
        $products = Product::all();
        return view('create', compact('products'));
    }
    public function store(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
            'delivery_address' => 'required|string|max:255',
        ]);

        // Получаем продукт из базы данных
        $product = Product::find($request->product_id);

        // Проверяем, достаточно ли товара на складе
        if ($request->quantity > $product->count) {
            return redirect()->back()->withErrors(['quantity' => 'Недостаточно товара на складе. Доступно: ' . $product->count]);
        }

        // Создаем заказ, добавляя user_id
        $order = Order::create([
            'product_id' => $request->product_id,
            'user_id' => auth()->id(), 
            'quantity' => $request->quantity,
            'delivery_address' => $request->delivery_address,
            'status' => 'Новый', 
        ]);

        // Уменьшаем количество товара на складе
        $product->count -= $request->quantity;
        $product->save();

        return redirect()->route('orders.create')->with('success', 'Заказ успешно создан!');
    }
   
}
