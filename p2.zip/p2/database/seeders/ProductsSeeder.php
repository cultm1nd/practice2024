<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('products')->insert([
            [
            'name' => 'Бананы',
                'price' => 500,
                'image' => 'img/ban.png',
                'count' => '15',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Картошка',
                    'price' => 600,
                    'image' => 'img/pot.png',
                    'count' => '5',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'name' => 'Торт',
                        'price' => 1000,
                        'image' => 'img/cake.png',
                        'count' => '5',
                        'created_at' => now(),
                        'updated_at' => now(),
                    ],
                    [
                        'name' => 'Помидоры',
                            'price' => 400,
                            'image' => 'img/tomato.png',
                            'count' => '7',
                            'created_at' => now(),
                            'updated_at' => now(),
                        ],
                        [
                            'name' => 'Яблоки',
                                'price' => 450,
                                'image' => 'img/7.jpg',
                                'count' => '6',
                                'created_at' => now(),
                                'updated_at' => now(),
                            ],
                            [
                                'name' => 'Сыр',
                                    'price' => 800,
                                    'image' => 'img/cheese.png',
                                    'count' => '9',
                                    'created_at' => now(),
                                    'updated_at' => now(),
                                ],
                    ]);
    }
}
