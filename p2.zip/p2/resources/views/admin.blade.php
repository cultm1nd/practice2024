@include'(header')
<h1>Hello, админ!</h1>