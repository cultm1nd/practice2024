<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('/css/style.css') }}">
    <title>Управление заказами</title>
</head>

<body>
    @include('header')
    <div class="container">
    <h1 class="my-4">Заказы</h1>

    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <form method="GET" action="{{ route('admin.orders.index') }}" class="mb-4">
        <div class="form-group">
            <label for="status">Фильтр по статусу:</label>
            <select name="status" id="status" class="form-control">
                <option value="">Все</option>
                <option value="Новый" {{ $status == 'Новый' ? 'selected' : '' }}>Новый</option>
                <option value="Подтвержден" {{ $status == 'Подтвержден' ? 'selected' : '' }}>Подтвержден</option>
                <option value="Отменен" {{ $status == 'Отменен' ? 'selected' : '' }}>Отменен</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Применить</button>
    </form>
    <table class="table table-bordered">
        <thead class="thead-light">
            <tr>
                <th>Имя пользователя</th>
                <th>Фамилия</th>
                <th>Отчество</th>
                <th>Email</th>
                <th>Наименование товара</th>
                <th>Количество</th>
                <th>Статус</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($orders as $order)
                <tr>
                    <td>{{ $order->user->name }}</td>
                    <td>{{ $order->user->surname }}</td>
                    <td>{{ $order->user->lastname }}</td>
                    <td>{{ $order->user->email }}</td>
                    <td>{{ $order->product->name }}</td>
                    <td>{{ $order->quantity }}</td>
                    <td>{{ $order->status }}</td>
                    <td>
                        @if ($order->status === 'Новый')
                            <form action="{{ route('admin.orders.update', $order) }}" method="POST" class="d-inline">
                                @csrf
                                <select name="status" class="form-control d-inline-block" style="width: auto;">
                                    <option value="Подтвержден">Подтвержден</option>
                                    <option value="Отменен">Отменен</option>
                                </select>
                                <button type="submit" class="btn btn-primary btn-sm">Изменить статус</button>
                            </form>
                        @else
                            <span class="text-muted">Статус не может быть изменен</span>
                        @endif
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
</body>
<script src="/bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>

</html>