<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('/css/style.css') }}">
    <title>Формирование заказа</title>
</head>

<body>
    @include('header')
    <div class="container mt-5">
        <h1 class="mb-4">Формирование заказа</h1>

        @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        <form action="{{ route('orders.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="product_id">Товар:</label>
                <select name="product_id" id="product_id" class="form-control" required>
                    <option value="">Выберите товар</option>
                    @foreach($products as $product)
                    <option value="{{ $product->id }}">{{ $product->name }}</option>
                    @endforeach
                </select>
            </div><br>
            <div class="form-group">
                <label for="quantity">Количество:</label>
                <input type="number" name="quantity" id="quantity" class="form-control" required min="1">
            </div><br>
            <div class="form-group">
                <label for="delivery_address">Адрес доставки:</label>
                <input type="text" name="delivery_address" id="delivery_address" class="form-control" required>
            </div><br>
            <button type="submit" class="btn btn-primary">Создать заказ</button>
            @if ($errors->any())
            <div>
                @foreach ($errors->all() as $error)
                <p>{{ $error }}</p>
                @endforeach
            </div>
            @endif
        </form>
    </div>
</body>
<script src="./jquery-3.7.1.js"></script>
<script src="./bootstrap-4.6.1-dist/js/bootstrap.min.js"></script>
<script src="/bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>

</html>