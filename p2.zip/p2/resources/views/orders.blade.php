<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('/css/style.css') }}">
    <title>Мои заказы</title>
</head>

<body>
    @include('header')
    <div class="container">
    <h1>Мои Заказы</h1>
    <a href="{{ route('orders.create') }}" class="btn btn-primary mb-3">Создать новый заказ</a>
    @if ($orders->isEmpty())
        <div class="alert alert-info">У вас нет заказов.</div>
    @else
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>№</th>
                    <th>Продукт</th>
                    <th>Количество</th>
                    <th>Статус</th>
                    <th>Дата создания</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($orders as $order)
                    <tr>
                        <td>{{ $order->id }}</td>
                        <td>{{ $order->product->name }}</td>
                        <td>{{ $order->quantity }}</td>
                        <td>{{ $order->status }}</td>
                        <td>{{ $order->created_at->format('d-m-Y H:i') }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>
    
</body>
<script src="./jquery-3.7.1.js"></script>
<script src="./bootstrap-4.6.1-dist/js/bootstrap.min.js"></script>
<script src="/bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</html>