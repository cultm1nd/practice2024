@include('header')
<div class="container">
<h1> «Авоська» </h1>
<p>Добро пожаловать в интернет-магазин "Авоська"! Удобный сервис по заказу продуктов под рукой.</p>
<p>Для заказа необходимо зарегестрироваться или авторизоваться.</p>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="./img/1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="./img/7.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="./img/5.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
 <button class="carousel-control-prev" type="button" data-target="#carouselExampleControls" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-target="#carouselExampleControls" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </button>
</div>
<!-- card product -->
<div class="container mt-5">
        <h1>Каталог товаров</h1>
        <div class="row">
            @foreach ($products as $product)
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="{{ $product->image}}" class="card-img-top" alt="{{ $product->name }}">
                    <div class="card-body">
                        <h5 class="card-title">{{ $product->name }}</h5>
                        <p class="card-text">Цена: {{ $product->price }} ₽</p>
                        <p class="card-text">
                            @if ($product->count > 0)
                            <span class="text-success">В наличии</span>
                            @else
                            <span class="text-danger">Нет в наличии</span>
                            @endif
                        </p>
                        @if ($product->count > 0)
                        @if (Auth::check())
                        @if (Auth::user()->role_id == 2)
                        <a href="{{ route('orders.create') }}" class="btn btn-primary">Заказать</a>
                        @endif
                        @else
                        <a href="{{ route('login') }}" class="btn btn-primary">Заказать</a>
                        @endif
                        @else
                        <button class="btn btn-secondary" disabled>Нет в наличии</button>
                        @endif
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>
<script src="./bootstrap-4.6.1-dist/js/bootstrap.min.js"></script>
<script src="./jquery-3.7.1.js"></script>
</body>
</html>