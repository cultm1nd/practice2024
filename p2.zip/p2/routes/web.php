<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\AdminController; 
use App\Http\Controllers\ProductController; 

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get('/', function () {
    return view('welcome');
})->name('home');

Route::get('/', [ProductController::class, 'index'])->name('home');

Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);


Route::get('/orders/create', [OrderController::class, 'create'])->name('orders.create');//создать заявку
Route::get('/orders/orders', [OrderController::class, 'orders'])->name('orders.orders');//мои заявки
Route::post('/orders', [OrderController::class, 'store'])->name('orders.store');


Route::get('/admin', [AdminController::class, 'index'])->middleware('auth')->name('admin');

Route::get('/admin/orders', [AdminController::class, 'index'])->name('admin.orders.index');
Route::post('/admin/orders/{order}', [AdminController::class, 'update'])->name('admin.orders.update');
 