<?php echo $__env->make('blocks.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
<h1>Hello, админ!</h1>
</div>
<?php /**PATH C:\OSPanel\domains\borovinskikh\p2\resources\views/admin/index.blade.php ENDPATH**/ ?>