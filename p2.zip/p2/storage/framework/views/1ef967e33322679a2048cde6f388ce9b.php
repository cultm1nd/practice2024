<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <link rel="stylesheet" href="./bootstrap-4.6.1-dist/css/bootstrap.min.css">
<style>
     
</style>
</head>
<body>
<div class="container">

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Авоська</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">Главная <span class="sr-only"></span></a>
      </li>
      
      <?php if(Auth::check()): ?>
      <?php if(Auth::user()->role_id == 2): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('orders.create')); ?>">Оформить заказ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('orders.orders')); ?>">Мои заказы</a>
                        </li>
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-primary" type="submit">Выйти</button>
                    </form>
                        <?php elseif(Auth::user()->role_id == 1): ?>
                        <li class="nav-item"><a href="<?php echo e(route('admin.orders.index')); ?>" class="nav-link">Управление заказами</a></li>
                        
    </ul>
  </div>
  <div class="d-flex">
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-primary" type="submit">Выйти</button>
                    </form>
                    <?php endif; ?>
                <?php else: ?>
                    <a class="btn btn-primary" href="<?php echo e(route('login')); ?>">Войти</a>
                    <a class="btn btn-light" href="<?php echo e(route('register')); ?>">Регистрация</a>
                <?php endif; ?>
            </div>
            
</nav>

</div>
<script src="./jquery-3.7.1.js"></script>
<script src="./bootstrap-4.6.1-dist/js/bootstrap.min.js"></script>
</body>
</html><?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p2\resources\views/header.blade.php ENDPATH**/ ?>