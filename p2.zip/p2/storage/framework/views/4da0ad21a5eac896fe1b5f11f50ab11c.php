<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    <title>Мои заказы</title>
</head>

<body>
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
    <h1>Мои Заказы</h1>
    <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-primary mb-3">Создать новый заказ</a>
    <?php if($orders->isEmpty()): ?>
        <div class="alert alert-info">У вас нет заказов.</div>
    <?php else: ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>№</th>
                    <th>Продукт</th>
                    <th>Количество</th>
                    <th>Статус</th>
                    <th>Дата создания</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->product->name); ?></td>
                        <td><?php echo e($order->quantity); ?></td>
                        <td><?php echo e($order->status); ?></td>
                        <td><?php echo e($order->created_at->format('d-m-Y H:i')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
    
</body>
<script src="./jquery-3.7.1.js"></script>

<script src="/bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</html><?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p2\resources\views/orders.blade.php ENDPATH**/ ?>