<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <link rel="stylesheet" href="./bootstrap-4.6.1-dist/css/bootstrap.min.css">
<style>
     
</style>
</head>
<body>
<div class="container">

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Авоська</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">Главная <span class="sr-only">(current)</span></a>
      </li>
      <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('catalog')); ?>">Каталог</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('reports')); ?>">Мои заказы</a>
                        </li>
                   <?php else: ?>
                  
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin')); ?>">Админ-панель</a>
                        </li>
                   
                    <?php endif; ?>
    </ul>
  </div>
  <div class="d-flex">
                <?php if(auth()->guard()->check()): ?>
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-primary" type="submit">Выйти</button>
                    </form>
                <?php else: ?>
                    <a class="btn btn-primary" href="<?php echo e(route('login')); ?>">Войти</a>
                    <a class="btn btn-light" href="<?php echo e(route('register')); ?>">Регистрация</a>
                <?php endif; ?>
            </div>
</nav>

</div>
<script src="./jquery-3.7.1.js"></script>
<script src="./bootstrap-4.6.1-dist/js/bootstrap.min.js"></script>
</body>
</html><?php /**PATH C:\OSPanel\domains\borovinskikh\p2\resources\views/blocks/header.blade.php ENDPATH**/ ?>