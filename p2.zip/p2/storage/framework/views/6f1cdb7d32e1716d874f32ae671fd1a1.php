<?php echo $__env->make('blocks.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
<h1> «Авоська» </h1>
<p>Добро пожаловать в интернет-магазин "Авоська"! Удобный сервис по заказу продуктов под рукой.</p>
<p>Для заказа необходимо зарегестрироваться или авторизоваться.</p>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="./img/1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="./img/7.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="./img/5.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
 <button class="carousel-control-prev" type="button" data-target="#carouselExampleControls" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-target="#carouselExampleControls" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </button>
</div>

</div>
<script src="./bootstrap-4.6.1-dist/js/bootstrap.min.js"></script>
<script src="./jquery-3.7.1.js"></script>
</body>
</html><?php /**PATH C:\OSPanel\domains\borovinskikh\p2\resources\views/welcome.blade.php ENDPATH**/ ?>