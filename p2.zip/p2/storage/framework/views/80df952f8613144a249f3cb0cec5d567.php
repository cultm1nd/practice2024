<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    <title>Формирование заказа</title>
</head>

<body>
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container mt-5">
        <h1 class="mb-4">Формирование заказа</h1>

        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('orders.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="product_id">Товар:</label>
                <select name="product_id" id="product_id" class="form-control" required>
                    <option value="">Выберите товар</option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div><br>
            <div class="form-group">
                <label for="quantity">Количество:</label>
                <input type="number" name="quantity" id="quantity" class="form-control" required min="1">
            </div><br>
            <div class="form-group">
                <label for="delivery_address">Адрес доставки:</label>
                <input type="text" name="delivery_address" id="delivery_address" class="form-control" required>
            </div><br>
            <button type="submit" class="btn btn-primary">Создать заказ</button>
            <?php if($errors->any()): ?>
            <div>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        </form>
    </div>
</body>
<script src="./jquery-3.7.1.js"></script>
<script src="./bootstrap-4.6.1-dist/js/bootstrap.min.js"></script>
<script src="/bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>

</html><?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p2\resources\views/create.blade.php ENDPATH**/ ?>