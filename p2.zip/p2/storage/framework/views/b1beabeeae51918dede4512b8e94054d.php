<?php echo $__env->make('blocks.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
<div class="card" style="width: 18rem;">
  <img src="..." class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
</div>
</div>
<script src="./jquery-3.7.1.js"></script>
<script src="./bootstrap-4.6.1-dist/js/bootstrap.min.js"></script>
<?php /**PATH C:\OSPanel\domains\borovinskikh\p2\resources\views/admin/catalogAdmin.blade.php ENDPATH**/ ?>