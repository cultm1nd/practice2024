<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/bootstrap-5.0.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    <title>Управление заказами</title>
</head>

<body>
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
    <h1 class="my-4">Заказы</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="GET" action="<?php echo e(route('admin.orders.index')); ?>" class="mb-4">
        <div class="form-group">
            <label for="status">Фильтр по статусу:</label>
            <select name="status" id="status" class="form-control">
                <option value="">Все</option>
                <option value="Новый" <?php echo e($status == 'Новый' ? 'selected' : ''); ?>>Новый</option>
                <option value="Подтвержден" <?php echo e($status == 'Подтвержден' ? 'selected' : ''); ?>>Подтвержден</option>
                <option value="Отменен" <?php echo e($status == 'Отменен' ? 'selected' : ''); ?>>Отменен</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Применить</button>
    </form>
    <table class="table table-bordered">
        <thead class="thead-light">
            <tr>
                <th>Имя пользователя</th>
                <th>Фамилия</th>
                <th>Отчество</th>
                <th>Email</th>
                <th>Наименование товара</th>
                <th>Количество</th>
                <th>Статус</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->user->name); ?></td>
                    <td><?php echo e($order->user->surname); ?></td>
                    <td><?php echo e($order->user->lastname); ?></td>
                    <td><?php echo e($order->user->email); ?></td>
                    <td><?php echo e($order->product->name); ?></td>
                    <td><?php echo e($order->quantity); ?></td>
                    <td><?php echo e($order->status); ?></td>
                    <td>
                        <?php if($order->status === 'Новый'): ?>
                            <form action="<?php echo e(route('admin.orders.update', $order)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <select name="status" class="form-control d-inline-block" style="width: auto;">
                                    <option value="Подтвержден">Подтвержден</option>
                                    <option value="Отменен">Отменен</option>
                                </select>
                                <button type="submit" class="btn btn-primary btn-sm">Изменить статус</button>
                            </form>
                        <?php else: ?>
                            <span class="text-muted">Статус не может быть изменен</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</body>
<script src="/bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>

</html><?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p2\resources\views/adminOrder.blade.php ENDPATH**/ ?>