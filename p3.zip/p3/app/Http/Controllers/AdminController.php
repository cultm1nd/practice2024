<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Production;
use App\Models\Korzina;
use App\Models\Order;
use App\Models\Korzintick;
use App\Models\Genre;
use App\Models\Ordtick;
use App\Models\Prodgen;
use Illuminate\Support\Facades\Storage;
use function Laravel\Prompts\alert;

class AdminController extends Controller
{
    public function GetCatalog(){
        if (Auth::check()) {
            if (Auth::user()->isAdmin==1) {
                $productions = Production::all();
                return view('Catalog',['productions'=>$productions]);
            }
            return redirect('/catalog');
        }
        return redirect('/login');
    }

    public function GetAddProduct(){
        if (Auth::check()) {
            if (Auth::user()->isAdmin==1) {
                return view('AddProduct',['genres'=>Genre::all()]);
            }
        }
    }
    public function GetGenres(){
        if (Auth::check()) {
            if (Auth::user()->isAdmin==1) {
                return view('Genres',['genres'=>Genre::all()]);
            }
        }
    }
    public function AddGen(Request $request)
    {
        if (Auth::check()) {
            if (Auth::user()->isAdmin==1) {
                $validate = $request->validate([
                    'genre_name'=>'required',
                ]);
                 $g=Genre::create([
                    'name'=>$validate['genre_name'],
                ]);
                return redirect('/admin/genres');
            }
        }
        return redirect('/catalog');
    }
    public function RemoveGenre($id)
    {
        if (Auth::check()) {
            if (Auth::user()->isAdmin==1) {
                $g = Genre::find($id);
                $gen = Prodgen::where(['genre_id'=>$id])->get();
                foreach($gen as $gg)
                {
                    $gg->delete();
                }
                $g->delete();
                return redirect('/admin/genres');
            }
        }
        return redirect('/catalog');
    }
    public function GetChangeProduct($id){
        if (Auth::check()) {
            if (Auth::user()->isAdmin==1) {
                return view('AddProduct',['curgenre'=>Prodgen::where(['production_id'=>$id])->first(),'genres'=>Genre::all(), 'production'=>Production::find($id)]);
            }
        }
    }

    public function ChangeProduct(Request $request, $id){
        if (Auth::check()) {
            if (Auth::user()->isAdmin==1) {
                $pr = Production::find($id);
                $validate = $request->validate([
                    'name'=>'required',
                    'date'=>'required',
                    'price'=>'required',
                    'limit'=>'required',
                    'count'=>'required',
                    'genre'=>'required',
                 ]);
                $fn = null;
                if ($request->file !=null) {
                    $file = $request->file('file');
                    $fn = $file->getClientOriginalName();
                }
                else{
                    $fn = $pr->img;
                }
                $pr->update(['name'=>$validate['name'],
                'show_date'=>$validate['date'],
                'age_limit'=>$validate['limit'],
                'count_ticket'=>$validate['count'],
                'price'=>$validate['price'],
                'img'=> $fn
                ]);
                $g=Prodgen::where(['production_id'=>$pr->id])->first();
                $g->update([
                    'genre_id'=>$validate['genre'],
                ]);
                return redirect('/admin');
            }
        }
        return redirect('/catalog');
    }

    public function AddProduct(Request $request){
        if (Auth::check()) {
            if (Auth::user()->isAdmin=1) {
                $validate = $request->validate([
                    'name'=>'required',
                    'date'=>'required',
                    'price'=>'required',
                    'limit'=>'required',
                    'count'=>'required',
                    'genre'=>'required',
                ]);
                $fn = null;
                if ($request->file!=null) {
                    $file = $request->file('file');
                    $fn = $file->getClientOriginalName();
                }
                $pr=Production::create([
                    'name'=>$validate['name'],
                    'show_date'=>$validate['date'],
                    'age_limit'=>$validate['limit'],
                    'count_ticket'=>$validate['count'],
                    'price'=>$validate['price'],
                    'img'=> $fn
                ]);
                Prodgen::create([
                    'production_id'=>$pr->id,
                    'genre_id'=>$validate['genre'],
                ]);
                return redirect('/admin');
            }
        }
        return redirect('/catalog');
    }

    public function RemoveProduct($id){
        if (Auth::check()) {
            if (Auth::user()->isAdmin==1) {
                $pr = Production::find($id);
                $gen = Prodgen::where(['production_id'=>$id])->first();
                $gen->delete();
                $pr->delete();
             return redirect('/admin');
            }
        }
        return redirect('/catalog');
    }

    public function GetOrders(){
        if (Auth::check()) {
            if (Auth::user()->isAdmin==1) {
                $orders = [];
                $or = Order::all();

                foreach ($or as $o) {
                    $prs = Ordtick::where('order_id',$o->id)->get();
                    $productions = [];
                    foreach ($prs as $pr) {
                        $productions[] = ['production'=>Production::find($pr->production_id),'count'=>$pr->count];
                    }
                    $u = User::find($o->user_id);
                    array_push($orders, ['order'=>$o,'user'=>$u,'productions'=>$productions]);
                }
                return view('CatalogOrders',['orders'=>$orders]);
            }
            return redirect('/order');
        }
        return redirect('/login');
    }

    public function ChangeStatus($id, Request $request){
         if (Auth::check()) {
            if (Auth::user()->isAdmin==1) {
                $order = Order::find($id);
                $order->status=$request->input('status');
                $order->save();
                return redirect('/admin/orders/');
            }
            return redirect('/order');
        }
        return redirect('/login');
    }
}


