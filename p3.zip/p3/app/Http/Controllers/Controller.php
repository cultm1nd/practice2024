<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;
     // if ($s != null) {
        //     if($p == null)
        //     {
        //         $pr = Production::where('id_type',$s)->get();
        //     }
        //     if($p == 1)
        //     {
        //         $pr = Production::orderBy('price')->where('id_type',$s)->get();

        //     }

        //     if($p == 2)
        //     {
        //         $pr = Production::orderBy('price', 'DESC')->where('id_type',$s)->get();
        //     }
        // }
        // if ($s == null) {
        //     if($p == 1)
        //     {
        //         $pr = Production::orderBy('price');
        //     }

        //     if($p == 2)
        //     {
        //         $pr=Production::orderBy('price','DESC');

        //     }
        // }

        // foreach ($pr as $p) {
        //     $productions[] = ['production'=>$p,"genre"=>Genre::find($p->id_type)->name];
        // }
}
