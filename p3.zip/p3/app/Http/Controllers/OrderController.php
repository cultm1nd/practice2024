<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Production;
use App\Models\Korzina;
use App\Models\Order;
use App\Models\Korzintick;
use App\Models\Ordtick;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function NewOrder(Request $request){
        if(Auth::check()){
            $user = Auth::user();
            $field = $request->validate(['password'=>'required',]);
            if (Auth::attempt(['login' => $user->login, 'password' => $field['password']])) {
                $korz = Korzina::where(['user_id'=>$user->id])->first();
                if (Korzintick::where(['korzina_id'=>$korz->id])->first()!==null) {
                    $order = Order::create([
                        'user_id'=>$user->id,
                        'status'=>'новый',
                    ]);
                    $order->save();
                    $tickets=Korzintick::where(['korzina_id'=>$korz->id])->get();
                    foreach($tickets as $ticket)
                    {
                        Ordtick::create([
                        'order_id'=>$order->id,
                        'production_id'=>$ticket->production_id,
                        'count'=>$ticket->count,
                        'place'=>$ticket->place,
                        ]);
                        $ticket->delete();
                    }

                    return redirect('/order');
                }
            }
            return redirect('/korzina');
        }
    }

    public function GetOrder(){
        $orders = [];
        $productions = [];
        if(Auth::check()){
            $user = Auth::user();
            $ord = Order::where(['user_id'=>$user->id])->get();
            foreach ($ord as $o) {
                $orp = Ordtick::where('order_id',$o->id)->get();
                $order = Order::where('id',$o->id)->first();
                foreach ($orp as $kp) {
                    array_push($productions,['production'=>Production::find($kp->production_id),'count'=>$kp->count]);
                }
                array_push($orders, ['order'=>$order,'productions'=>$productions,]);
            }
            }
            return view('CatalogOrders',['orders'=>$orders]);
    }

    public function RemoveOrder($id){
        if (Auth::check()) {
            $user = Auth::user();
            $ord = Order::where(['id'=>$id])->first();
            $prod=Ordtick::where(['order_id'=>$id])->get();
            foreach ($prod as $k) {
                if ($ord->status=='новый') {
                    $product=Production::find($k->production_id)->increment('count_ticket', $k->count);
                    $k->delete();
                }
            }
            $ord->delete();
            return redirect('/order');
        }
    }
}
