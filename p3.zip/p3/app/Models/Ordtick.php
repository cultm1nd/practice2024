<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Ordtick extends Model
{
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }
    public function production(): BelongsTo
    {
        return $this->belongsTo(Production::class);
    }
    use HasFactory;
    protected $fillable = [
        'order_id',
        'production_id',
        'count',
        'place',
    ];
}
