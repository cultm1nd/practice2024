<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Prodgen extends Model
{
    public function production(): BelongsTo
    {
        return $this->belongsTo(Production::class);
    }
    public function genre(): BelongsTo
    {
        return $this->belongsTo(Genre::class);
    }

    use HasFactory;
    protected $fillable = [
        'production_id',
        'genre_id',
    ];
}
