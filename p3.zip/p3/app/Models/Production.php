<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
class Production extends Model
{
    public function prodgens(): HasMany
    {
        return $this->hasMany(Prodgen::class);
    }
    public function korzinticks(): HasMany
    {
        return $this->hasMany(Korzintick::class);
    }
    public function ordticks(): HasMany
    {
        return $this->hasMany(Ordtick::class);
    }
    use HasFactory;
    protected $fillable = [
        'name',
        'img',
        'show_date',
        'age_limit',
        'price',
        'count_ticket',
    ];
}
