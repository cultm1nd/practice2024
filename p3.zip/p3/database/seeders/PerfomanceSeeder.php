<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class PerfomanceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('perfomances')->insert([
            [
            'title'=>'Драма номер 5',
            'description'=>'Спектакль о драме между влюбленными',
            'show_date' =>'2024-12-12 20:00:00',
            'age_limit'=>'18',
            'price'=>'1000',
            'genre_id'=>'1',


            ],
            [
                'title'=>'Смайлик',
            'description'=>'Интересная комедия о друзьях',
            'show_date' =>'2024-12-05 20:00:00',
            'age_limit'=>'16',
            'price'=>'600',
            'genre_id'=>'2',  
                ],
                [
                    'title'=>'Петербруг',
                'description'=>'Интересная мистерия о культурной столице нашей страны',
                'show_date' =>'2024-12-15 20:00:00',
                'age_limit'=>'6',
                'price'=>'1500',
                'genre_id'=>'3',  
                    ],
                    ]);
    }
}
