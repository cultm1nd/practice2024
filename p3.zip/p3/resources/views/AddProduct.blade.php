@extends('Layout')
@section('content')

@if(isset($production))
<form method="POST" action="{{URL::to('/admin/changeprod/'.$production->id)}}" class="w-50 m-auto" enctype="multipart/form-data">
    @csrf
    <h1 class="h3 mb-3 fw-normal">Изменить постановку</h1>
    <div class="form-floating m-2">
        <input type="file" name="file" class="form-control" id="floatingPassword" accept="image/png, image/jpeg" placeholder="Img">
        <label for="floatingPassword">Изображение</label>
    </div>
    <div class="form-floating m-2">
        <input name="name" class="form-control" id="floatingInput" value="{{$production->name}}" placeholder="name">
        <label for="floatingInput">Название</label>
    </div>
    <div class="form-floating m-2">
        <input type="date" name="date" class="form-control" id="floatingPassword" value="{{$production->show_date}}" placeholder="Date">
        <label for="floatingPassword">Дата</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="price" class="form-control" id="floatingPassword" value="{{$production->price}}" placeholder="Date">
        <label for="floatingPassword">Цена</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="limit" class="form-control" id="floatingPassword" value="{{$production->age_limit}}" placeholder="Date">
        <label for="floatingPassword">Возраст</label>
    </div>
   
    <div class="form-floating m-2">
        <input type="number" name="count" class="form-control" id="floatingPassword" value="{{$production->count_ticket}}" placeholder="Date">
        <label for="floatingPassword">Кол-во билетов</label>
    </div>
    <div class="form-floating m-2">
        <select name="genre" class="form-select">
            <option value="0">Жанр</option>
            @foreach ($genres as $genre)
            <option value="{{$genre->id}}" @if($curgenre->id == $genre->id ) @selected(true) @endif>{{$genre->name}}</option>
            @endforeach
        </select>
        <label for="floatingPassword">Жанр</label>
    </div>
    <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Изменить</button>
</form>
@else
<form method="POST" action="{{URL::to('/admin/addprod')}}" class="w-50 m-auto" enctype="multipart/form-data">
    @csrf
    <h1 class="h3 mb-3 fw-normal">Добавить постановку</h1>
    <div class="form-floating m-2">
        <input type="file" name="file" class="form-control" id="floatingPassword" accept="image/png, image/jpeg" placeholder="Img" required>
        <label for="floatingPassword">Изображение</label>
    </div>
    <div class="form-floating m-2">
        <input name="name" class="form-control" id="floatingInput" value="" placeholder="name" required>
        <label for="floatingInput">Название</label>
    </div>
    <div class="form-floating m-2">
        <input type="date" name="date" class="form-control" id="floatingPassword" value="" placeholder="Date" required>
        <label for="floatingPassword">Дата</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="price" class="form-control" id="floatingPassword" value="" placeholder="Date" required>
        <label for="floatingPassword">Цена</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="limit" class="form-control" id="floatingPassword" value="" placeholder="Date" required>
        <label for="floatingPassword">Возраст</label>
    </div>
    
    <div class="form-floating m-2">
        <input type="number" name="count" class="form-control" id="floatingPassword" value="" placeholder="Date" required>
        <label for="floatingPassword">Кол-во билетов</label>
    </div>
    <div class="form-floating m-2">
        <select name="genre" class="form-select">
            <option value="0">Жанр</option>
            @foreach ($genres as $genre)
            <option value="{{$genre->id}}">{{$genre->name}}</option>
            @endforeach
        </select>
        <label for="floatingPassword">Жанр</label>
    </div>
    <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Добавить</button>
</form>

@endif



@endsection
@show
