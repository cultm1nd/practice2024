@extends('Layout')
@section('content')

<div class="album py-5 bg-body-tertiary">
    <div class="container">
        @if (Auth::check())
            @if (Auth::user()->isAdmin == 1)
                <button type="button" class="btn btn-primary text-white btn-outline-secondary m-4" onclick="window.location.href = '{{URL::to('/admin/addprod')}}'">Добавить постановку</button>
            @endif
        @endif

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
    @foreach ($productions as $production)
        <div class="col">
            <div class="card shadow-sm border-light" style="width: 300px; transition: transform 0.2s;">
                <a href="{{URL::to('catalog/pr/'.$production->id)}}">
                    <img src="{{url('/images/'.$production->img)}}" alt="" class="card-img-top" style="border-top-left-radius: 0.25rem; border-top-right-radius: 0.25rem;">
                </a>
                <div class="card-body">
                    <h4 class="card-title">Название: {{$production->name}}</h4>
                    <h5 class="card-text">Цена: {{$production->price}} р.</h5>
                    <h5 class="card-text">Возраст: {{$production->age_limit}}+</h5>
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="btn-group">
                            @if (Auth::check())
                                @if (Auth::user()->isAdmin==1)
                                    <button type="button" class="btn btn-primary text-white" onclick="window.location.href = '{{URL::to('admin/changeprod/'.$production->id)}}'">Изменить</button>
                                    <button type="button" class="btn btn-light text-black" onclick="window.location.href = '{{URL::to('admin/remove/'.$production->id)}}'">Удалить</button>
                                @else
                                    @if($production->count_ticket>0)
                                        <button class="btn btn-primary" onclick="window.location.href = '{{URL::to('/add/'.$production->id)}}'">Добавить в корзину</button>
                                    @else
                                        <button class="btn btn-secondary" disabled>Sold out</button>
                                    @endif
                                @endif
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endforeach
</div>
        </div>
    </div>
</div>
@endsection
@show
