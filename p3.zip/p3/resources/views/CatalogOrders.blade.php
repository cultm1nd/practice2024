@extends('Layout')
@section('content')

@if (Auth::check())
    <div class="album py-5 bg-light">
        <div class="container">
            <h1 class="text-center mb-4">Мои Заказы</h1>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
                @foreach ($orders as $order)
                    <div class="col">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h4 class="card-title text-center">Заказ № {{$order['order']->id}}</h4>
                                @if (Auth::user()->isAdmin == 0)
                                    @foreach ($order['productions'] as $prod)
                                        <p class="card-text">Постановка: {{$prod['production']->name}}</p>
                                        <p class="card-text">Кол-во билетов: {{$prod['count']}}</p>
                                    @endforeach
                                    <p class="card-text">Статус: <span class="badge bg-secondary">{{$order['order']->status}}</span></p>
                                    @if($order['order']->status == 'новый')
                                        <button type="button" class="btn btn-primary" onclick="window.location.href = '{{URL::to('order/remove/'.$order['order']->id)}}'">Удалить</button>
                                    @endif
                                @else
                                    <h5 class="card-subtitle mb-2 text-muted">Заказчик: {{$order['user']->name}} {{$order['user']->surname}} {{$order['user']->patronymic}}</h5>
                                    @foreach ($order['productions'] as $prod)
                                        <p class="card-text">Постановка: {{$prod['production']->name}}</p>
                                        <p class="card-text">Кол-во билетов: {{$prod['count']}}</p>
                                    @endforeach
                                    <p class="card-text">Статус: <span class="badge bg-secondary">{{$order['order']->status}}</span></p>
                                    <p class="card-text">Дата создания: {{$order['order']->created_at}}</p>
                                    @if($order['order']->status == 'новый')
                                        <form action="{{URL::to('/admin/changestatus/'.$order['order']->id)}}" method="POST" class="mt-2">
                                            @csrf
                                            <div class="input-group">
                                                <select name="status" class="form-select">
                                                    <option value="0">Выберите статус</option>
                                                    <option value="подтвержденный">Подтвержденный</option>
                                                    <option value="отмененный">Отмененный</option>
                                                </select>
                                                <button type="submit" class="btn btn-info">Изменить</button>
                                            </div>
                                        </form>
                                    @endif
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endif

@endsection

