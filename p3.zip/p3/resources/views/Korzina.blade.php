@extends('Layout')
@section('content')

<div class="container mt-5">
    <h1 class="text-center mb-4">Корзина</h1>
    
    @if ($productions != null)
        <div class="album py-5">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
                @foreach ($productions as $production)
                    <div class="col">
                        <div class="card shadow-sm border-light">
                            <img src="../../images/{{$production['product'][0]['img']}}" class="card-img-top" alt="{{$production['product'][0]['name']}}" style="height: 200px; object-fit: cover;">
                            <div class="card-body text-center">
                                <h5 class="card-title">{{$production['product'][0]['name']}}</h5>
                                <div class="d-flex justify-content-center align-items-center">
                                    <button type="button" class="btn btn-dark btn-outline-secondary text-white h3 me-2" onclick="window.location.href = '{{URL::to('/add/'.$production['product'][0]['id'].'/1')}}'">+</button>
                                    <p class="h3 p-2">{{$production['count']}}</p>
                                    <button type="button" class="btn btn-dark btn-outline-secondary text-white h3 ms-2" onclick="window.location.href = '{{URL::to('/remove/'.$production['product'][0]['id'])}}'">-</button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <br>
            <h2 class="text-center">К оплате: {{$p}} р.</h2>
            <div class="text-center">
                <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-dark btn-outline-secondary text-white h3">Оформление заказа</button>
            </div>

            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Подтвердите заказ</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <h5>Введите пароль</h5>
                            <form action="{{URL::to('/order/new')}}" method="POST">
                                @csrf
                                <div class="form-floating mb-3">
                                    <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password" required>
                                    <label for="floatingPassword">Пароль</label>
                                </div>
                                <button class="btn btn-primary w-100 py-2" type="submit">Отправить</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @else
        <h2 class="text-center">В корзине пусто =(</h2>
    @endif
</div>

@endsection

