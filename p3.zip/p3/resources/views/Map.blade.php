@extends('Layout')
@section('content')
    <div class="m-5 row">
        <div class="col">
            <h1><p class="m-2">Адрес: г.Каменск-Уральский, ул.Сибирская,15</p></h1>
            <h1><p class="m-2">Телефон: +7-952-952-52-52</p></h1>
            <h1><p class="m-2">Эл. почта: omega@mail.ru</p></h1>
        </div>
        
    </div>
    <div class="col">
        <img src="{{URL::to('/images/map.jpg')}}" class="d-block " alt="..." style="width:1000px;height:500px">
    </div>
@endsection
@show
