@extends('Layout')
@section('content')
<div class="d-flex align-items-center py-4 bg-body-tertiary m-0 h-100">
    <main class="form-signin w-50 m-auto p-5">
  <form method="POST" action="{{URL::to('/register')}}">
     <!-- onsubmit="event.preventDefault();Validate();"> -->
    <H1>Регистрация</H1>
    @csrf
    <div class="form-floating m-2">
      <p>Имя</p>
      <input class="form-control" id="floatingInput name" placeholder="Name" name="name" required style="border-radius:50px;">
  
    </div>
    <div class="form-floating m-2">
    <p>Фамилия</p>
      <input class="form-control" id="floatingInput surname" placeholder="Surname" name="surname" required style="border-radius:50px;">

    </div>
    <div class="form-floating m-2">
    <p>Отчество</p>
      <input class="form-control" id="floatingInput" placeholder="Patronymic" name="patr" style="border-radius:50px;">
    </div>
    <div class="form-floating m-2">
    <p>Электронная почта</p>
        <input required type="email" class="form-control" id="floatingInput email" placeholder="name@example.com" name="email" style="border-radius:50px;">
    </div>
    <div class="form-floating m-2">
    <p>Логин</p>
      <input required class="form-control" id="floatingInput login" placeholder="Login" name="login" style="border-radius:50px;">
    </div>
    <div class="form-floating m-2">
    <p>Пароль</p>
      <input required type="password" class="form-control password" id="floatingPassword " placeholder="Password" name="password" style="border-radius:50px;">
     
    </div>
    <div class="form-floating m-2">
    <p>Повторите пароль</p>
      <input required type="password" class="form-control rpassword" id="floatingPassword d" placeholder="Password" name="password_repeat" style="border-radius:50px;">
    </div>
    <div class="m-2">
        <input required type="checkbox" class=" rules" id="floatingPassword" name="rules" >
      <label for="floatingPassword">Я со всем согласен</label>
    </div>
    <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Регистрация</button>
    <a href='{{URL::to('/login')}}'>Уже есть аккаунт? Войти</a>
  </form>
    </main>
</div>

<!-- <script src="../public/sign.js"/> -->
@endsection
@show
