<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <link rel="stylesheet" href="./bootstrap-5.0.2-dist/css/bootstrap.min.css">
<style>
     
</style>
</head>
<body>
<div class="container">

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="{{ route('home') }}">Омега</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="{{ route('home') }}">О нас <span class="sr-only"></span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="{{ route('afisha') }}">Афиша<span class="sr-only"></span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="{{ route('where') }}">Где нас найти?<span class="sr-only"></span></a>
      </li>
      
      @if (Auth::check())
      @if (Auth::user()->role_id == 2)
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('orders.create') }}">Мои билеты</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('orders.orders') }}">Мои заказы</a>
                        </li>
                        <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button class="btn btn-primary" type="submit">Выйти</button>
                    </form>
                        @elseif (Auth::user()->role_id == 1)
                        <li class="nav-item"><a href="{{ route('admin.orders.index') }}" class="nav-link">Управление заказами</a></li>
                        
    </ul>
  </div>
  <div class="d-flex">
                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button class="btn btn-primary" type="submit">Выйти</button>
                    </form>
                    @endif
                @else
                    <a class="btn btn-primary" href="{{ route('login') }}">Войти</a>
                    <a class="btn btn-light" href="{{ route('register') }}">Регистрация</a>
                @endif
            </div>
            
</nav>

</div>
<script src="./jquery-3.7.1.js"></script>
<script src="./bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>