<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\AdminController;
use Illuminate\Support\Facades\Auth;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [ProductController::class, 'About']);
Route::get('/map', function () {
    return view('map');
});

Route::get('/login', function () {
    if(Auth::check())
    {
        return redirect('/catalog');
    }
    return view('Auth');
});
Route::get('/register', function () {
     if(Auth::check())
        {
            return redirect('/catalog');
        }
    return view('Regist');
});
Route::get('/logout',function(){
    Auth::logout();
    return redirect(to:'/');
})->name(name:'logout');

Route::get('/catalog/{s?}/{p?}', [ProductController::class,'All'])->whereNumber(['s','p']);
Route::get('/catalog/pr/{id}', [ProductController::class,'One']);

Route::post('/order/new', [OrderController::class, 'NewOrder']);
Route::get('/order', [OrderController::class, 'GetOrder']);
Route::get('/order/remove/{id}', [OrderController::class, 'RemoveOrder']);

Route::get('/korzina', [UserController::class, 'GetKorzina']);
Route::get('/add/{id}/{c?}', [UserController::class, 'AddToKorzina']);
Route::get('/remove/{id}', [UserController::class, 'RemoveFromKorzina']);

Route::get('/admin', [AdminController::class, 'GetCatalog']);
Route::get('/admin/addprod', [AdminController::class, 'GetAddProduct']);
Route::get('/admin/changeprod/{id}', [AdminController::class, 'GetChangeProduct']);
Route::get('/admin/remove/{id}', [AdminController::class, 'RemoveProduct']);
Route::get('/admin/orders', [AdminController::class,'GetOrders']);
Route::get('/admin/genres', [AdminController::class,'GetGenres']);
Route::get('/admin/gen/remove/{id}', [AdminController::class, 'RemoveGenre']);


Route::post('/register', [UserController::class, 'Regist']);
Route::post('/login', [UserController::class, 'Auth']);
Route::post('/admin/addprod', [AdminController::class,'AddProduct']);


Route::post('/admin/addgenres', [AdminController::class,'AddGen']);

Route::post('/admin/changestatus/{id}', [AdminController::class, 'ChangeStatus']);
Route::post('/admin/changeprod/{id}', [AdminController::class, 'ChangeProduct']);

