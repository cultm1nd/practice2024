<?php $__env->startSection('content'); ?>
<div class="album py-5 bg-body-tertiary">
    

        <form class="mt-4" action="<?php echo e(URL::to('/admin/addgenres')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <h1>Добавьте новый жанр</h1>
            <input class="form-control w-50" type="text"  name="genre_name" required>
            <button class="btn btn-primary" type="submit">Добавить</button>
        </form>
    </div>
<div class="container">
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <div class="col">
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card " style="width: 250px;">
                    <h4 class="text-center"><?php echo e($genre->name); ?></h4>
                    <button type="button" class="btn btn-primary" onclick="window.location.href = '<?php echo e(URL::to('admin/gen/remove/'.$genre->id)); ?>'">Удалить</button><br>
                </div><br><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p3\resources\views/Genres.blade.php ENDPATH**/ ?>