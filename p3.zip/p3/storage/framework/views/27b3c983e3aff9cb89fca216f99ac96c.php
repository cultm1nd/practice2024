<?php $__env->startSection('content'); ?>

<?php if(Auth::check()): ?>
    <div class="album py-5 bg-light">
        <div class="container">
            <h1 class="text-center mb-4">Мои Заказы</h1>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h4 class="card-title text-center">Заказ № <?php echo e($order['order']->id); ?></h4>
                                <?php if(Auth::user()->isAdmin == 0): ?>
                                    <?php $__currentLoopData = $order['productions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="card-text">Постановка: <?php echo e($prod['production']->name); ?></p>
                                        <p class="card-text">Кол-во билетов: <?php echo e($prod['count']); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <p class="card-text">Статус: <span class="badge bg-secondary"><?php echo e($order['order']->status); ?></span></p>
                                    <?php if($order['order']->status == 'новый'): ?>
                                        <button type="button" class="btn btn-primary" onclick="window.location.href = '<?php echo e(URL::to('order/remove/'.$order['order']->id)); ?>'">Удалить</button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <h5 class="card-subtitle mb-2 text-muted">Заказчик: <?php echo e($order['user']->name); ?> <?php echo e($order['user']->surname); ?> <?php echo e($order['user']->patronymic); ?></h5>
                                    <?php $__currentLoopData = $order['productions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="card-text">Постановка: <?php echo e($prod['production']->name); ?></p>
                                        <p class="card-text">Кол-во билетов: <?php echo e($prod['count']); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <p class="card-text">Статус: <span class="badge bg-secondary"><?php echo e($order['order']->status); ?></span></p>
                                    <p class="card-text">Дата создания: <?php echo e($order['order']->created_at); ?></p>
                                    <?php if($order['order']->status == 'новый'): ?>
                                        <form action="<?php echo e(URL::to('/admin/changestatus/'.$order['order']->id)); ?>" method="POST" class="mt-2">
                                            <?php echo csrf_field(); ?>
                                            <div class="input-group">
                                                <select name="status" class="form-select">
                                                    <option value="0">Выберите статус</option>
                                                    <option value="подтвержденный">Подтвержденный</option>
                                                    <option value="отмененный">Отмененный</option>
                                                </select>
                                                <button type="submit" class="btn btn-info">Изменить</button>
                                            </div>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p3\resources\views/CatalogOrders.blade.php ENDPATH**/ ?>