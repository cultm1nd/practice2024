<?php $__env->startSection('content'); ?>

<div class="justify-content-center row w-75 m-auto">
    <div class="col">
        <img src="../../images/<?php echo e($production->img); ?>" style="width:400px">
    <div class="col">
        <h1>Название: <?php echo e($production->name); ?></h1>
        <p>Дата показа: <?php echo e($production->show_date); ?></p>
        <p>Возрастной ценз: <?php echo e($production->age_limit); ?>+</p>
        <p>Цена: <?php echo e($production->price); ?></p>
        <p>Жанр: <?php echo e($genre[0]); ?></p>
        <?php if(Auth::check()): ?>
            <?php if($production->count_ticket>0): ?>
                <button class="btn btn-primary" onclick="window.location.href = '<?php echo e(URL::to('/add/'.$production->id)); ?>'">Добавить в корзину</button> 
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\teatr\resources\views/Product.blade.php ENDPATH**/ ?>