<?php $__env->startSection('content'); ?>

<?php if(isset($production)): ?>
<form method="POST" action="<?php echo e(URL::to('/admin/changeprod/'.$production->id)); ?>" class="w-50 m-auto" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <h1 class="h3 mb-3 fw-normal">Изменить постановку</h1>
    <div class="form-floating m-2">
        <input type="file" name="file" class="form-control" id="floatingPassword" accept="image/png, image/jpeg" placeholder="Img">
        <label for="floatingPassword">Изображение</label>
    </div>
    <div class="form-floating m-2">
        <input name="name" class="form-control" id="floatingInput" value="<?php echo e($production->name); ?>" placeholder="name">
        <label for="floatingInput">Название</label>
    </div>
    <div class="form-floating m-2">
        <input type="date" name="date" class="form-control" id="floatingPassword" value="<?php echo e($production->show_date); ?>" placeholder="Date">
        <label for="floatingPassword">Дата</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="price" class="form-control" id="floatingPassword" value="<?php echo e($production->price); ?>" placeholder="Date">
        <label for="floatingPassword">Цена</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="limit" class="form-control" id="floatingPassword" value="<?php echo e($production->age_limit); ?>" placeholder="Date">
        <label for="floatingPassword">Возраст</label>
    </div>
   
    <div class="form-floating m-2">
        <input type="number" name="count" class="form-control" id="floatingPassword" value="<?php echo e($production->count_ticket); ?>" placeholder="Date">
        <label for="floatingPassword">Кол-во билетов</label>
    </div>
    <div class="form-floating m-2">
        <select name="genre" class="form-select">
            <option value="0">Жанр</option>
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($genre->id); ?>" <?php if($curgenre->id == $genre->id ): ?> <?php if(true): echo 'selected'; endif; ?> <?php endif; ?>><?php echo e($genre->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="floatingPassword">Жанр</label>
    </div>
    <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Изменить</button>
</form>
<?php else: ?>
<form method="POST" action="<?php echo e(URL::to('/admin/addprod')); ?>" class="w-50 m-auto" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <h1 class="h3 mb-3 fw-normal">Добавить постановку</h1>
    <div class="form-floating m-2">
        <input type="file" name="file" class="form-control" id="floatingPassword" accept="image/png, image/jpeg" placeholder="Img" required>
        <label for="floatingPassword">Изображение</label>
    </div>
    <div class="form-floating m-2">
        <input name="name" class="form-control" id="floatingInput" value="" placeholder="name" required>
        <label for="floatingInput">Название</label>
    </div>
    <div class="form-floating m-2">
        <input type="date" name="date" class="form-control" id="floatingPassword" value="" placeholder="Date" required>
        <label for="floatingPassword">Дата</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="price" class="form-control" id="floatingPassword" value="" placeholder="Date" required>
        <label for="floatingPassword">Цена</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="limit" class="form-control" id="floatingPassword" value="" placeholder="Date" required>
        <label for="floatingPassword">Возраст</label>
    </div>
    
    <div class="form-floating m-2">
        <input type="number" name="count" class="form-control" id="floatingPassword" value="" placeholder="Date" required>
        <label for="floatingPassword">Кол-во билетов</label>
    </div>
    <div class="form-floating m-2">
        <select name="genre" class="form-select">
            <option value="0">Жанр</option>
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="floatingPassword">Жанр</label>
    </div>
    <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Добавить</button>
</form>

<?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p3\resources\views/AddProduct.blade.php ENDPATH**/ ?>