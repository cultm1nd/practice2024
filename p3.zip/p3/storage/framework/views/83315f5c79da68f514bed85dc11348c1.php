<?php $__env->startSection('content'); ?>
    <div class="m-5 row">
        <div class="col">
            <h1><p class="m-2">Адрес: г.Каменск-Уральский, ул.Сибирская,15</p></h1>
            <h1><p class="m-2">Телефон: +7-952-952-52-52</p></h1>
            <h1><p class="m-2">Эл. почта: omega@mail.ru</p></h1>
        </div>
        
    </div>
    <div class="col">
        <img src="<?php echo e(URL::to('/images/map.jpg')); ?>" class="d-block " alt="..." style="width:1000px;height:500px">
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p3\resources\views/map.blade.php ENDPATH**/ ?>