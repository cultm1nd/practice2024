<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-light" style="border-radius: 1rem;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="../../images/<?php echo e($production->img); ?>" class="img-fluid rounded-start" alt="<?php echo e($production->name); ?>" style="border-top-left-radius: 1rem; border-bottom-left-radius: 1rem; height: 100%; object-fit: cover;">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h1 class="card-title"><?php echo e($production->name); ?></h1>
                            <p class="card-text"><strong>Дата показа:</strong> <?php echo e($production->show_date); ?></p>
                            <p class="card-text"><strong>Возрастной ценз:</strong> <?php echo e($production->age_limit); ?>+</p>
                            <p class="card-text"><strong>Цена:</strong> <?php echo e($production->price); ?> р.</p>
                            <p class="card-text"><strong>Жанр:</strong> <?php echo e($genre[0]); ?></p>
                            <?php if(Auth::check()): ?>
                                <?php if($production->count_ticket > 0): ?>
                                    <button class="btn btn-primary" onclick="window.location.href = '<?php echo e(URL::to('/add/'.$production->id)); ?>'">Добавить в корзину</button> 
                                <?php else: ?>
                                    <button class="btn btn-secondary" disabled>Sold out</button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p3\resources\views/Product.blade.php ENDPATH**/ ?>