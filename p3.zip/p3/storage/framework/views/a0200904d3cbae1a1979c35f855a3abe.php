<?php $__env->startSection('content'); ?>

<div class="album py-5 bg-body-tertiary">
    <div class="container">
        <?php if(Auth::check()): ?>
            <?php if(Auth::user()->isAdmin == 1): ?>
                <button type="button" class="btn btn-primary text-white btn-outline-secondary m-4" onclick="window.location.href = '<?php echo e(URL::to('/admin/addprod')); ?>'">Добавить постановку</button>
            <?php endif; ?>
        <?php endif; ?>

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
    <?php $__currentLoopData = $productions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $production): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card shadow-sm border-light" style="width: 300px; transition: transform 0.2s;">
                <a href="<?php echo e(URL::to('catalog/pr/'.$production->id)); ?>">
                    <img src="<?php echo e(url('/images/'.$production->img)); ?>" alt="" class="card-img-top" style="border-top-left-radius: 0.25rem; border-top-right-radius: 0.25rem;">
                </a>
                <div class="card-body">
                    <h4 class="card-title">Название: <?php echo e($production->name); ?></h4>
                    <h5 class="card-text">Цена: <?php echo e($production->price); ?> р.</h5>
                    <h5 class="card-text">Возраст: <?php echo e($production->age_limit); ?>+</h5>
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="btn-group">
                            <?php if(Auth::check()): ?>
                                <?php if(Auth::user()->isAdmin==1): ?>
                                    <button type="button" class="btn btn-primary text-white" onclick="window.location.href = '<?php echo e(URL::to('admin/changeprod/'.$production->id)); ?>'">Изменить</button>
                                    <button type="button" class="btn btn-light text-black" onclick="window.location.href = '<?php echo e(URL::to('admin/remove/'.$production->id)); ?>'">Удалить</button>
                                <?php else: ?>
                                    <?php if($production->count_ticket>0): ?>
                                        <button class="btn btn-primary" onclick="window.location.href = '<?php echo e(URL::to('/add/'.$production->id)); ?>'">Добавить в корзину</button>
                                    <?php else: ?>
                                        <button class="btn btn-secondary" disabled>Sold out</button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p3\resources\views/Catalog.blade.php ENDPATH**/ ?>