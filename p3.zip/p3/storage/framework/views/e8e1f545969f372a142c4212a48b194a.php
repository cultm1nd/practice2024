<?php $__env->startSection('content'); ?>
<?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin == 0): ?>
<div class="album py-5 bg-body-tertiary">
    <div class="container">

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card " style="width: 200px;">
                    <h4 class="text-center">Заказ № <?php echo e($order['order']->id); ?></h4><br>
                    <?php $__currentLoopData = $order['productions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p>Постановка: <?php echo e($prod['production']->name); ?></p>
                        <p>Количество билетов:  <?php echo e($prod['count']); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <p>Статус: <?php echo e($order['order']->status); ?></p>
                    <?php if($order['order']->status == 'новый'): ?>
                    <button type="button" class="btn btn-danger text-white btn-outline-secondary " onclick="window.location.href = '<?php echo e(URL::to('order/remove/'.$order['order']->id)); ?>'">Удалить</button>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php else: ?>
<div class="album py-5 bg-body-tertiary">
    <div class="container">

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card " style="width: 300px;">
                    <h4 class="text-center">Заказ № <?php echo e($order['order']->id); ?></h4><br>
                    <h4 class="text-start">Заказчик: <?php echo e($order['user']->name); ?> <?php echo e($order['user']->surname); ?> <?php echo e($order['user']->patronymic); ?></h4><br>
                    <?php $__currentLoopData = $order['productions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p>Постановка: <?php echo e($prod['production']->name); ?></p>
                        <p>Количество билетов:  <?php echo e($prod['count']); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <p>Статус: <?php echo e($order['order']->status); ?></p>
                    <p>Дата создания: <?php echo e($order['order']->created_at); ?></p>
                    <?php if($order['order']->status == 'новый'): ?>
                    <form action="<?php echo e(URL::to('/admin/changestatus/'.$order['order']->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <select name="status" id="">
                            <option value="0">Выберете статус</option>
                            <option value="подтвержденный">подтвержденный</option>
                            <option value="отмененый">отмененый</option>
                        </select>
                        <button type="submit" class="btn btn-info text-white btn-outline-secondary " >Изменить</button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\teatr\resources\views/CatalogOrders.blade.php ENDPATH**/ ?>