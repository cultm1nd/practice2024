<?php if(!Auth::check()): ?>
<div class="p-3 text-dark bg-white">
    <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start" >
            <h1><a href='<?php echo e(URL::to('/')); ?>' style="text-decoration:none; color:black">ОМЕГА</a></h1>
            <ul class="nav col-10 col-lg-auto me-lg-auto ms-auto justify-content-center mb-md-0">
              <li><a class="nav-link px-2 text-black" href = '<?php echo e(URL::to('/')); ?>'>О нас</a></li>
                <li><a href = '<?php echo e(URL::to('/catalog')); ?>' class="nav-link px-2 text-black">Афиша</a></li>
                <li><a href = '<?php echo e(URL::to('/map')); ?>' class="nav-link px-2 text-black">Где нас найти?</a></li>
            </ul>

        <div class="text-end">
            <button type="button" onclick=" window.location.href = '<?php echo e(URL::to('/login')); ?>'" class="btn btn-primary text-light me-2">Войти</button>
            <button type="button" class="btn btn-light text-dark" onclick="window.location.href='<?php echo e(URL::to('/register')); ?>'">Регистрация</button>
        </div>
    </div>

</div>
<?php endif; ?>

<?php if(Auth::check()): ?>
<?php if(Auth::user()->isAdmin == 0): ?>
<div class="p-3 mb-3 text-dark bg-white">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
      <h1><a href='<?php echo e(URL::to('/')); ?>' style="text-decoration:none; color:black">ОМЕГА</a></h1>

        <ul class="nav col-12 col-lg-auto me-lg-auto ms-auto justify-content-center mb-md-0">
          <li><a href = '<?php echo e(URL::to('/catalog')); ?>' class="nav-link px-2 text-black">Афиша</a></li>
                <li><a href = '<?php echo e(URL::to('/map')); ?>' class="nav-link px-2 text-black">Где нас найти?</a></li>
                <li><a class="nav-link px-2 text-black" href = '<?php echo e(URL::to('/')); ?>'>О нас</a></li>
        </ul>

            <li><a class="nav-link px-2 text-black" href="<?php echo e(URL::to('/korzina')); ?>">Корзина</a></li>
            <li><a class="nav-link px-2 text-black" href="<?php echo e(URL::to('/order')); ?>">Заказы</a></li>
            <li><a class="nav-link px-2 text-black " href="<?php echo e(URL::to('/logout')); ?>">Выйти</a></li>
          </ul>
      </div>
    </div>
</div>
<?php else: ?>
<div class="px-3 py-2 text-dark bg-white">
      <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <h1><a href="<?php echo e(URL::to('/admin')); ?>" style="text-decoration:none; color:black">ОМЕГА</a></h1>

          <ul class="nav col-12 col-lg-auto my-2 justify-content-center my-md-0 text-small">
          <li>
              <a href="<?php echo e(URL::to('/admin')); ?>" class="nav-link text-black">
                Управление постановками
              </a>
            </li>
            <li>
              <a href="<?php echo e(URL::to('/admin/genres')); ?>" class="nav-link text-black">
                Управление жанрами
              </a>
            </li>
            <li>
              <a href="<?php echo e(URL::to('/admin/orders')); ?>" class="nav-link text-dark">
               Управление заказами
              </a>
            </li>
            <li>
              <a href="<?php echo e(URL::to('/logout')); ?>" class="nav-link text-black">
                Выйти
              </a>
            </li>
          </ul>
        </div>
      </div>
</div>
<?php endif; ?>

<?php endif; ?>

<?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p3\resources\views/Head.blade.php ENDPATH**/ ?>