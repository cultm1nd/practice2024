<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{  
    public function login(Request $request)
    {
        // dd($request);
        $user=User::where(['login'=>$request->login,'password'=>$request->password])->first();
        if(is_null($user))
        {
            return redirect()->back();
        }
        Auth::loginUsingId($user->id);
        return redirect('/');
    }

    public function logout(Request $request)
    {
        Auth::logout();

        return redirect('/');
    }
}
