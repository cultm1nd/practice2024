<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Driver;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class DriverController extends Controller
{  
    public function index()
    {
        $drivers = Driver::all();
        return view('listDriver', compact('drivers'));
    }

    public function createDriver()
    {
        return view('driver');
    }

    public function storeDriver(Request $request)
    {
        
    
        $driver = new Driver();
        $driver->name = $request->input('name');
        $driver->birth_date = $request->input('birth_date');
        $driver->email = $request->input('email');
        $driver->phone = $request->input('phone');
        $driver->vehicle_id = null;
    
        if ($request->hasFile('avatar')) {
            $image = $request->file('avatar');
            $imageName = $image->getClientOriginalName();
            $image->move(public_path('images'), $imageName);
            $driver->avatar = $imageName;
        }
    
        $driver->save();
    
        return redirect()->route('driver')->with('success', 'Статья успешно создана!');
    }
    


    public function editDriver($id)
{
    $driver = Driver::findOrFail($id);
    return view('editDriver', compact('driver'));
}

public function updateDriver(Request $request, $id)
{
    $driver = Driver::findOrFail($id);
    $driver->name = $request->input('name');
    $driver->birth_date = $request->input('birth_date');
    $driver->email = $request->input('email');
    $driver->phone = $request->input('phone');

    if ($request->hasFile('avatar')) {
        $image = $request->file('avatar');
        $imageName = $image->getClientOriginalName();
        $image->move(public_path('images'), $imageName);
        $driver->avatar = $imageName;
    }

    $driver->save();
    return redirect()->route('listDriver')->with('success', 'Driver updated successfully!');
}

public function destroyDriver($id)
{
    $driver = Driver::findOrFail($id);
    $driver->delete();
    return redirect()->route('listDriver')->with('success', 'Driver deleted successfully!');
}

}
