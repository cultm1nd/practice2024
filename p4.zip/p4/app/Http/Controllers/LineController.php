<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Line;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class LineController extends Controller
{

    public function index()
    {
        $lines = Line::all();
        return view('listLine', compact('lines'));
    }


    public function createLine()
    {
        return view('line');
    }


    public function storeLine(Request $request)
    {
        $line = new Line();

        // dd($request);
        // Set default value for start_time_operation if empty

        $line->name = $request->input('name');
        $line->start_time_operation = $request->start_time_operation;
        $line->end_time_operation = $request->end_time_operation;
        $line->type = $request->input('type');

        if ($request->hasFile('map')) {
            $image = $request->file('map');
            $imageName = $image->getClientOriginalName();
            $image->move(public_path('images'), $imageName);
            $line->map = $imageName;
        }

        $line->save();
        $imagePath = asset('images/' . $imageName);
        return redirect()->route('line')->with('success', 'Статья успешно создана!');
    }



    public function editLine($id)
    {
        $line = Line::findOrFail($id);
        return view('editLine', compact('line'));
    }


    public function updateLine(Request $request, $id)
    {
        $line = Line::findOrFail($id);
        $line->name = $request->input('name');
        $line->start_time_operation = $request->input('start_time_operation');
        $line->end_time_operation = $request->input('end_time_operation');
        $line->type = $request->input('type');

        if ($request->hasFile('map')) {
            $image = $request->file('map');
            $imageName = $image->getClientOriginalName();
            $image->move(public_path('images'), $imageName);
            $line->map = $imageName;
        }

        $line->save();
        return redirect()->route('listLine')->with('success', 'Line updated successfully!');
    }


    public function destroyLine($id)
    {
        $line = Line::findOrFail($id);
        $line->delete();

        return redirect()->route('listLine')->with('success', 'Line deleted successfully.');
    }
}
