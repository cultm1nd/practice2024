<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Line;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class LineController extends Controller
{  

    public function index()
    {
        $lines = Line::all(); 
        return view('listLine', compact('lines')); 
    }

   
    public function createLine()
    {
        return view('line'); 
    }

    
    public function storeLine(Request $request)
    {
        $request->validate([
            'name' => 'required|max:50',
            'start_time_operation' => 'required',
            'end_time_operation' => 'required',
            'type' => 'nullable',
            'map' => 'required|file|mimes:jpg,png,pdf',
        ]);

        
        $mapPath = $request->file('map')->store('maps');

      
        Line::create([
            'name' => $request->name,
            'start_time_operation' => $request->start_time_operation,
            'end_time_operation' => $request->end_time_operation,
            'type' => $request->type,
            'map' => $mapPath,
        ]);

        return redirect()->route('line')->with('success', 'Line created successfully.');
    }

 
    public function editLine($id)
    {
        $line = Line::findOrFail($id); 
        return view('editLine', compact('line')); 
    }

    
    public function updateLine(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|max:50',
            'start_time_operation' => 'required',
            'end_time_operation' => 'required',
            'type' => 'nullable',
            'map' => 'nullable|file|mimes:jpg,png,pdf', 
        ]);

        $line = Line::findOrFail($id); 
        $line->name = $request->name;
        $line->start_time_operation = $request->start_time_operation;
        $line->end_time_operation = $request->end_time_operation;
        $line->type = $request->type;


        if ($request->hasFile('map')) {
            $mapPath = $request->file('map')->store('maps');
            $line->map = $mapPath;
        }

        $line->save(); 

        return redirect()->route('listLine')->with('success', 'Line updated successfully.');
    }

  
    public function destroyLine($id)
    {
        $line = Line::findOrFail($id); 
        $line->delete(); 

        return redirect()->route('listLine')->with('success', 'Line deleted successfully.');
    }
}
