<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Station;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class StationController extends Controller
{  
    public function index()
    {
        $stations = Station::all();
        return view('listStation', compact('stations'));
    }

    public function createStation()
    {
        return view('station');
    }

    public function storeStation(Request $request)
    {
        $request->validate(['name' => 'required|max:80']);
        Station::create($request->all());
        return redirect()->route('listStation');
    }

    public function editStation($id)
    {
        $station = Station::findOrFail($id);
        return view('editStation', compact('station'));
    }

    public function updateStation(Request $request, $id)
    {
        $request->validate(['name' => 'required|max:80']);
        $station = Station::findOrFail($id);
        $station->update($request->all());
        return redirect()->route('listStation');
    }

    public function destroyStation($id)
    {
        $station = Station::findOrFail($id);
        $station->delete();
        return redirect()->route('listStation');
    }
}
