<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Vehicle;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class VehicleController extends Controller
{
    public function index()
    {
        $vehicles = Vehicle::all();
        return view('listVehicle', compact('vehicles'));
    }


    public function createVehicle()
    {
        return view('vehicle');
    }


    public function storeVehicle(Request $request)
    {
        $vehicle = new Vehicle();

        // dd($request);
        // Set default value for start_time_operation if empty

        $vehicle->name = $request->input('name');
        $vehicle->capacity = $request->input('capacity');
        $vehicle->type = $request->input('type');
        $vehicle->line_id = null;

        $vehicle->save();
        return redirect()->route('vehicle')->with('success', 'Статья успешно создана!');
    }



    public function editVehicle($id)
    {
        $vehicle = Vehicle::findOrFail($id);
        return view('editVehicle', compact('vehicle'));
    }


    public function updateVehicle(Request $request, $id)
    {
        $vehicle = Vehicle::findOrFail($id);
        $vehicle->name = $request->input('name');
        $vehicle->capacity = $request->input('capacity');
        $vehicle->type = $request->input('type');

        $vehicle->save();
        return redirect()->route('listVehicle')->with('success', 'Line updated successfully!');
    }


    public function destroyVehicle($id)
    {
        $vehicle = Vehicle::findOrFail($id);
        $vehicle->delete();

        return redirect()->route('listVehicle')->with('success', 'Line deleted successfully.');
    }
}
