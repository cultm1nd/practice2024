<h1>Edit Line</h1>

<form enctype="multipart/form-data" action="{{ route('updateLine', $line->id) }}" method="POST">
    @csrf
    @method('PUT')

    <div class="row">
        <label for="Line_name">Name</label>
        <input size="50" maxlength="50" name="name" id="Line_name" type="text" value="{{ $line->name }}" required>
    </div>

    <div class="row">
        <label for="start_time_operation">Start Time Operation</label>
        <input type="time" name="start_time_operation" id="start_time_operation" value="{{ $line->start_time_operation }}" required>
    </div>

    <div class="row">
        <label for="end_time_operation">End Time Operation</label>
        <input type="time" name="end_time_operation" id="end_time_operation" value="{{ $line->end_time_operation }}" required>
    </div>

    <div class="row">
        <label for="Line_type">Type</label>
        <select name="type" id="Line_type">
            <option value="Tram" {{ $line->type == 'Tram' ? 'selected' : '' }}>Tram</option>
            <option value="Bus" {{ $line->type == 'Bus' ? 'selected' : '' }}>Bus</option>
            <option value="Nightliner" {{ $line->type == 'Nightliner' ? 'selected' : '' }}>Nightliner</option>
            <option value="Regionalbus" {{ $line->type == 'Regionalbus' ? 'selected' : '' }}>Regionalbus</option>
        </select>
    </div>

    <div class="row">
        <label for="Line_map">Map</label>
        <input name="map" id="Line_map" type="file">
        <p>Current map: <a href="{{ asset($line->map) }}">View</a></p>
    </div>

    <div class="row buttons">
        <input type="submit" value="Update">
    </div>
</form>