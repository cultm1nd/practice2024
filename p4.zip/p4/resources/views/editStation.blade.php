<h1>Edit Station</h1>
    <form action="{{ route('updateStation', $station->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div>
            <label for="name">Name <span>*</span></label>
            <input type="text" name="name" id="name" value="{{ $station->name }}" required>
        </div>
        <button type="submit">Update</button>
    </form>