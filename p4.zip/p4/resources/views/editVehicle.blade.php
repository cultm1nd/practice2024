<h1>Edit Vehicle</h1>

<form enctype="multipart/form-data" action="{{ route('updateVehicle', $vehicle->id) }}" method="POST">
    @csrf
    @method('PUT')

    <div class="row">
        <label for="Vehicle_name">Name</label>
        <input size="50" maxlength="50" name="name" id="Vehicle_name" type="text" value="{{ $vehicle->name }}" required>
    </div>

    <div class="row">
        <label for="Vehicle_capacity">Capacity</label>
        <input size="50" maxlength="50" name="capacity" id="Vehicle_capacity" type="text" value="{{ $vehicle->capacity }}" required>
    </div>

    <div class="row">
        <label for="Vehicle_type">Type</label>
        <select name="type" id="Vehicle_type">
            <option value="Tram" {{ $vehicle->type == 'Tram' ? 'selected' : '' }}>Tram</option>
            <option value="Bus" {{ $vehicle->type == 'Bus' ? 'selected' : '' }}>Bus</option>
            <option value="Nightliner" {{ $vehicle->type == 'Nightliner' ? 'selected' : '' }}>Nightliner</option>
            <option value="Regionalbus" {{ $vehicle->type == 'Regionalbus' ? 'selected' : '' }}>Regionalbus</option>
        </select>
    </div>

    <div class="row buttons">
        <input type="submit" value="Update">
    </div>
</form>