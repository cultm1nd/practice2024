<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="language" content="en" />

        <link rel="stylesheet" type="text/css" href="/src/css/core.css" media="screen, projection" />
        <link rel="stylesheet" type="text/css" href="/src/css/principal.css" />
        <link rel="stylesheet" type="text/css" href="/src/css/nav.css" />
        <link rel="stylesheet" type="text/css" href="/src/css/content.css" />
        <link rel="stylesheet" type="text/css" href="/src/css/form.css" />
        <link rel="stylesheet" type="text/css" href="/src/css/footer.css" />

        <title>WorldSkills Leipzig / Leipziger Verkehrsbetriebe</title>
<style>
    .driver-avatar {
    width: 100px;  
    height: 100px; 
    object-fit: cover; 
    
}
    </style>
    </head>

    <body>

        <div class="container" id="page">

        <a href="{{route('index')}}">
                <div id="header">
                    <div id="logo"><!--WorldSkills Leipzig / Leipziger Verkehrsbetriebe--></div>
                </div></a>

            <div id="mainmenu">

            <ul>
                    <li>
                        <a href="{{route('line')}}" title="Line"><span style="background-image: url(src/images/line.png)"></span><!--Line--></a>
                    </li>
                    <li>
                        <a href="{{route('station')}}" title="Station"><span style="background-image: url(src/images/station.png)"></span><!--Station--></a>
                    </li>
                    <li>
                        <a href="{{route('vehicle')}}" title="Vehicle"><span style="background-image: url(src/images/vehicle.png)"></span><!--Vehicle--></a>
                    </li>
                    <li>
                        <a href="{{route('driver')}}" title="Driver"><span style="background-image: url(src/images/driver.png)"></span><!--Driver--></a>
                    </li>
                    <li>
                        <a href="{{route('xml')}}" title="XML-XSD"><span style="background-image: url(src/images/xml.png)"></span><!--XML Schema--></a>
                    </li>
                    @if(Auth::check()==false)
                    <li>
                        <a href="{{route('user')}}" title="User"><span style="background-image: url(src/images/user.png)"></span><!--User--></a>
                    </li>
                    @endif
                </ul>

                <!-- Login / Logout -->
                <div id='access'>
                    <div>Webmaster (<a href="#">Logout</a>)</div> 
                </div>
            </div>

           <!-- вывод драйверов -->
           <h1>Stations</h1>
           <a href="{{ route('station') }}">Create Station</a><br><br>
           @foreach ($stations as $station)
           <ul style="border:1px solid darkblue">
               <li>
                   {{ $station->name }}
                   <a href="{{ route('editStation', $station->id) }}">Edit</a>
                   <form action="{{ route('deleteStation', $station->id) }}" method="POST" style="display:inline;">
                       @csrf
                       @method('DELETE')
                       <button type="submit">Delete</button>
                    </form>
                </li>
            </ul>
            @endforeach
            <div class="stations"></div>





                                        <!-- content -->



                                        </div>
                                        <div class="span-5 last">
                                            <div id="sidebar">
                                                <div class="portlet" >
                                                    <div class="portlet-decoration">
                                                        <div class="portlet-title">Operations</div>
                                                    </div>
                                                    <div class="portlet-content">
                                                        <ul class="operations" >
                                                            <li><a href="#list">List Driver</a></li>
                                                            <li><a href="#manage">Manage Driver</a></li>
                                                        </ul></div>
                                                </div>	
                                            </div><!-- sidebar -->
                                        </div>

                                        <div class="clear"></div>

                                        <div id="footer">
                                            <ul>
                                                <li class="sitemap"><a href="#">Site Map</a></li>
                                                <li class="copyr"><a href="#">Copyright &copy; 2013 by LVB</a></li>
                                                <li class="allright"><a href="#">All Rights Reserved. <br>By WorldSkills International</a></li>
                                            </ul>
                                        </div><!-- footer -->

                                        </div><!-- page -->

                                        </body>
                                        </html>
