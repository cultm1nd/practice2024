<!DOCTYPE html>
<html>

<head>
    <title>Uploaded Image</title>
</head>

<body>
    <h1>Uploaded Map Image</h1>

    @if(isset($imagePath))
    <img src="{{ $imagePath }}" alt="Map Image">
    @else
    <p>No image was uploaded.</p>
    @endif

    <a href="{{ route('listLine') }}">Back to Line List</a>
</body>

</html>