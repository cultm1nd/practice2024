<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DriverController;
use App\Http\Controllers\VehicleController;
use App\Http\Controllers\StationController;
use App\Http\Controllers\LineController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('index');
})->name('index');
Route::get('/line', function () {
    return view('line');
})->name('line');
Route::get('/xml', function () {
    return view('xml');
})->name('xml');
Route::get('/user', function () {
    return view('user');
})->name('user');
Route::get('/station', function () {
    return view('station');
})->name('station');
Route::get('/vehicle', function () {
    return view('vehicle');
})->name('vehicle');
Route::get('/driver', function () {
    return view('driver');
})->name('driver');


Route::post('/login', [AuthController::class, 'login'])->name('login');
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');
//drivers
Route::get('/driver/listDriver', [DriverController::class, 'index'])->name('listDriver');
Route::get('/driver/create', [DriverController::class, 'createDriver'])->name('createDriver');
Route::post('/driver', [DriverController::class, 'storeDriver'])->name('storeDriver');
Route::get('/driver/edit/{id}', [DriverController::class, 'editDriver'])->name('editDriver');
Route::put('/driver/update/{id}', [DriverController::class, 'updateDriver'])->name('updateDriver');
Route::delete('/driver/delete/{id}', [DriverController::class, 'destroyDriver'])->name('deleteDriver');
// lines
Route::get('/line/listLine', [LineController::class, 'index'])->name('listLine');
Route::get('/line/create', [LineController::class, 'createLine'])->name('createLine');
Route::post('/line', [LineController::class, 'storeLine'])->name('storeLine');
Route::get('/line/edit/{id}', [LineController::class, 'editLine'])->name('editLine');
Route::put('/line/update/{id}', [LineController::class, 'updateLine'])->name('updateLine');
Route::delete('/line/delete/{id}', [LineController::class, 'destroyLine'])->name('deleteLine');
Route::get('/line/show/{id}', [LineController::class, 'showImage'])->name('showImage');
//stations
Route::get('/station/listStation', [StationController::class, 'index'])->name('listStation');
Route::get('/station/create', [StationController::class, 'createStation'])->name('createStation');
Route::post('/station', [StationController::class, 'storeStation'])->name('storeStation');
Route::get('/station/edit/{id}', [StationController::class, 'editStation'])->name('editStation');
Route::put('/station/update/{id}', [StationController::class, 'updateStation'])->name('updateStation');
Route::delete('/station/delete/{id}', [StationController::class, 'destroyStation'])->name('deleteStation');
//vehicles
Route::get('/vehicle/listVehicle', [VehicleController::class, 'index'])->name('listVehicle');
Route::get('/vehicle/create', [VehicleController::class, 'createVehicle'])->name('createVehicle');
Route::post('/vehicle', [VehicleController::class, 'storeVehicle'])->name('storeVehicle');
Route::get('/vehicle/edit/{id}', [VehicleController::class, 'editVehicle'])->name('editVehicle');
Route::put('/vehicle/update/{id}', [VehicleController::class, 'updateVehicle'])->name('updateVehicle');
Route::delete('/vehicle/delete/{id}', [VehicleController::class, 'destroyVehicle'])->name('deleteVehicle');
