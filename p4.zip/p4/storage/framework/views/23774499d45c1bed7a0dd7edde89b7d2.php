<h1>Edit Station</h1>
    <form action="<?php echo e(route('updateStation', $station->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <label for="name">Name <span>*</span></label>
            <input type="text" name="name" id="name" value="<?php echo e($station->name); ?>" required>
        </div>
        <button type="submit">Update</button>
    </form><?php /**PATH C:\OSPanel\domains\borovinskikh\p4\resources\views/editStation.blade.php ENDPATH**/ ?>