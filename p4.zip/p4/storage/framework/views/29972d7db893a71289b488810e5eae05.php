<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="language" content="en" />

        <link rel="stylesheet" type="text/css" href="src/css/core.css" media="screen, projection" />
        <link rel="stylesheet" type="text/css" href="src/css/principal.css" />
        <link rel="stylesheet" type="text/css" href="src/css/nav.css" />
        <link rel="stylesheet" type="text/css" href="src/css/content.css" />
        <link rel="stylesheet" type="text/css" href="src/css/form.css" />
        <link rel="stylesheet" type="text/css" href="src/css/footer.css" />

        <title>WorldSkills Leipzig / Leipziger Verkehrsbetriebe</title>

    </head>

    <body>

        <div class="container" id="page">

        <a href="<?php echo e(route('index')); ?>">
                <div id="header">
                    <div id="logo"><!--WorldSkills Leipzig / Leipziger Verkehrsbetriebe--></div>
                </div></a>

            <div id="mainmenu">

            <ul>
                    <li>
                        <a href="<?php echo e(route('line')); ?>" title="Line"><span style="background-image: url(src/images/line.png)"></span><!--Line--></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('station')); ?>" title="Station"><span style="background-image: url(src/images/station.png)"></span><!--Station--></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('vehicle')); ?>" title="Vehicle"><span style="background-image: url(src/images/vehicle.png)"></span><!--Vehicle--></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('driver')); ?>" title="Driver"><span style="background-image: url(src/images/driver.png)"></span><!--Driver--></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('xml')); ?>" title="XML-XSD"><span style="background-image: url(src/images/xml.png)"></span><!--XML Schema--></a>
                    </li>
                    <?php if(Auth::check()==false): ?>
                    <li>
                        <a href="<?php echo e(route('user')); ?>" title="User"><span style="background-image: url(src/images/user.png)"></span><!--User--></a>
                    </li>
                    <?php endif; ?>
                </ul>

                <!-- Login / Logout -->
                <div id='access'>
                    <div>Webmaster (<a href="<?php echo e(route('logout')); ?>">Logout</a>)</div> 
                </div>
            </div>

            <!-- mainmenu -->
            <div class="breadcrumbs">
                <a href="#">Home</a> &raquo; <a href="#">Line</a> &raquo; <span>Create</span></div><!-- breadcrumbs -->

            <div class="span-19">


                <div id="lines">

                <h1>List of Lines</h1><br><br>
                <a href="<?php echo e(route('line')); ?>">Create New Line</a>

<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Type</th>
            <th>Map</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr >
                <td><?php echo e($line->name); ?></td>
                <td><?php echo e($line->start_time_operation); ?></td>
                <td><?php echo e($line->end_time_operation); ?></td>
                <td><?php echo e($line->type); ?></td>
                <td><a href="<?php echo e(asset($line->map)); ?>">View Map</a></td>
                <td>
                    <a href="<?php echo e(route('editLine', $line->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('deleteLine', $line->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</div>
</div>

                    </div><!-- content -->



                                        </div>
                                        <div class="span-5 last">
                                            <div id="sidebar">
                                                <div class="portlet" >
                                                    <div class="portlet-decoration">
                                                        <div class="portlet-title">Operations</div>
                                                    </div>
                                                    <div class="portlet-content">
                                                        <ul class="operations" >
                                                            <li><a href="#list">List Line</a></li>
                                                            <li><a href="#manage">Manage Line</a></li>
                                                        </ul></div>
                                                </div>	</div><!-- sidebar -->
                                        </div>

                                        <div class="clear"></div>

                                        <div id="footer">
                                            <ul>
                                                <li class="sitemap"><a href="#">Site Map</a></li>
                                                <li class="copyr"><a href="#">Copyright &copy; 2013 by LVB</a></li>
                                                <li class="allright"><a href="#">All Rights Reserved. <br>By WorldSkills International</a></li>
                                            </ul>
                                        </div><!-- footer -->

                                        </div><!-- page -->

                                        </body>
                                        </html>
<?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p4\resources\views/listLine.blade.php ENDPATH**/ ?>