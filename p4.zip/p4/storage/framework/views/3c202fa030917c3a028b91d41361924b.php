<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="language" content="en" />

        <link rel="stylesheet" type="text/css" href="src/css/core.css" media="screen, projection" />
        <link rel="stylesheet" type="text/css" href="src/css/principal.css" />
        <link rel="stylesheet" type="text/css" href="src/css/nav.css" />
        <link rel="stylesheet" type="text/css" href="src/css/content.css" />
        <link rel="stylesheet" type="text/css" href="src/css/form.css" />
        <link rel="stylesheet" type="text/css" href="src/css/footer.css" />

        <title>WorldSkills Leipzig / Leipziger Verkehrsbetriebe</title>

    </head>

    <body>

        <div class="container" id="page">

            <a href="index.html">
                <div id="header">

                </div></a>

            <div id="mainmenu">

                <ul>
                    <li>
                        <a href="<?php echo e(route('line')); ?>" title="Line"><span style="background-image: url(src/images/line.png)"></span><!--Line--></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('station')); ?>" title="Station"><span style="background-image: url(src/images/station.png)"></span><!--Station--></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('vehicle')); ?>" title="Vehicle"><span style="background-image: url(src/images/vehicle.png)"></span><!--Vehicle--></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('driver')); ?>" title="Driver"><span style="background-image: url(src/images/driver.png)"></span><!--Driver--></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('xml')); ?>" title="XML-XSD"><span style="background-image: url(src/images/xml.png)"></span><!--XML Schema--></a>
                    </li>
                    <?php if(Auth::check()==false): ?>
                    <li>
                        <a href="<?php echo e(route('user')); ?>" title="User"><span style="background-image: url(src/images/user.png)"></span><!--User--></a>
                    </li>
                    <?php endif; ?>
                </ul>

                <!-- Login / Logout -->
                <div id='access'>
                    <div>Webmaster (<a href="<?php echo e(route('logout')); ?>">Logout</a>)</div> 
                </div>
            </div>

            <!-- mainmenu --><!-- breadcrumbs -->


            <div id="content">

                <h1>Welcome to <i>LVB Leipzig</i></h1>

                <p>The largest transport company in Leipzig, LVB (Leipziger VerkehrsBetriebe) translated into English as the “Leipzig Transport Company”, operates the tramway and bus transport services in Leipzig.</p>
                <p>The LVB route network is a part of the regional public transport association and was formed by merger, from January 1917. Public transport in Leipzig is characterized by a dense light-rail system.</p>
                <p>13 tram lines serve a transport area of about 152 kilometers, complemented by more than 30 bus lines in large part being en-route in the suburban area. </p>
                <img width="670" src="src/images/Routes.svg" alt="Avatar"></div>
            <!-- content -->
            <div class="clear"></div>

            <div id="footer">
                <ul>
                    <li class="sitemap"><a href="#">Site Map</a></li>
                    <li class="copyr"><a href="#">Copyright &copy; 2013 by LVB</a></li>
                    <li class="allright"><a href="#">All Rights Reserved. <br>By WorldSkills International</a></li>
                </ul>
            </div><!-- footer -->

        </div><!-- page -->

    </body>
</html>
<?php /**PATH C:\OSPanel\domains\borovinskikh\p4\resources\views/index.blade.php ENDPATH**/ ?>