<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Driver</title>
    <link rel="stylesheet" type="text/css" href="/src/css/core.css" media="screen, projection" />

</head>
<body>

    <div class="container">
        <h1>Edit Driver</h1>
        <form action="<?php echo e(route('updateDriver', $driver->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <label for="Driver_name">Name</label>
        <input type="text" name="name" id="Driver_name" value="<?php echo e($driver->name); ?>">
    </div>
    <div class="row">
        <label for="Driver_birth_date">Birth Date</label>
        <input type="text" name="birth_date" id="Driver_birth_date" value="<?php echo e($driver->birth_date); ?>">
    </div>
    <div class="row">
        <label for="Driver_email">Email</label>
        <input type="text" name="email" id="Driver_email" value="<?php echo e($driver->email); ?>">
    </div>
    <div class="row">
        <label for="Driver_phone">Phone</label>
        <input type="text" name="phone" id="Driver_phone" value="<?php echo e($driver->phone); ?>">
    </div>
    <div class="row">
        <label for="Driver_avatar">Avatar</label>
        <input type="file" name="avatar" id="Driver_avatar">
    </div>
    <div class="row buttons">
        <input type="submit" value="Update">
    </div>
</form>
    </div>

</body>
</html><?php /**PATH C:\OSPanel\domains\borovinskikh\4course\p4\resources\views/editDriver.blade.php ENDPATH**/ ?>