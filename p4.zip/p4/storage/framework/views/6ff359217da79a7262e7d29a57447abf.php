<h1>Edit Line</h1>

<form enctype="multipart/form-data" action="<?php echo e(route('updateLine', $line->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row">
        <label for="Line_name">Name</label>
        <input size="50" maxlength="50" name="name" id="Line_name" type="text" value="<?php echo e($line->name); ?>" required>
    </div>

    <div class="row">
        <label for="start_time_operation">Start Time Operation</label>
        <input type="time" name="start_time_operation" id="start_time_operation" value="<?php echo e($line->start_time_operation); ?>" required>
    </div>

    <div class="row">
        <label for="end_time_operation">End Time Operation</label>
        <input type="time" name="end_time_operation" id="end_time_operation" value="<?php echo e($line->end_time_operation); ?>" required>
    </div>

    <div class="row">
        <label for="Line_type">Type</label>
        <select name="type" id="Line_type">
            <option value="Tram" <?php echo e($line->type == 'Tram' ? 'selected' : ''); ?>>Tram</option>
            <option value="Bus" <?php echo e($line->type == 'Bus' ? 'selected' : ''); ?>>Bus</option>
            <option value="Nightliner" <?php echo e($line->type == 'Nightliner' ? 'selected' : ''); ?>>Nightliner</option>
            <option value="Regionalbus" <?php echo e($line->type == 'Regionalbus' ? 'selected' : ''); ?>>Regionalbus</option>
        </select>
    </div>

    <div class="row">
        <label for="Line_map">Map</label>
        <input name="map" id="Line_map" type="file">
        <p>Current map: <a href="<?php echo e(asset($line->map)); ?>">View</a></p>
    </div>

    <div class="row buttons">
        <input type="submit" value="Update">
    </div>
</form><?php /**PATH C:\OSPanel\domains\borovinskikh\p4\resources\views/editLine.blade.php ENDPATH**/ ?>