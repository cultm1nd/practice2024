<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="language" content="en" />

        <link rel="stylesheet" type="text/css" href="/src/css/core.css" media="screen, projection" />
        <link rel="stylesheet" type="text/css" href="/src/css/principal.css" />
        <link rel="stylesheet" type="text/css" href="/src/css/nav.css" />
        <link rel="stylesheet" type="text/css" href="/src/css/content.css" />
        <link rel="stylesheet" type="text/css" href="/src/css/form.css" />
        <link rel="stylesheet" type="text/css" href="/src/css/footer.css" />

        <title>WorldSkills Leipzig / Leipziger Verkehrsbetriebe</title>

    </head>

    <body>

        <div class="container" id="page">

            <a href="index.html">
                <div id="header">
                    <div id="logo"><!--WorldSkills Leipzig / Leipziger Verkehrsbetriebe--></div>
                </div></a>

            <div id="mainmenu">

            <ul>
                    <li>
                        <a href="<?php echo e(route('line')); ?>" title="Line"><span style="background-image: url(src/images/line.png)"></span><!--Line--></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('station')); ?>" title="Station"><span style="background-image: url(src/images/station.png)"></span><!--Station--></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('vehicle')); ?>" title="Vehicle"><span style="background-image: url(src/images/vehicle.png)"></span><!--Vehicle--></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('driver')); ?>" title="Driver"><span style="background-image: url(src/images/driver.png)"></span><!--Driver--></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('xml')); ?>" title="XML-XSD"><span style="background-image: url(src/images/xml.png)"></span><!--XML Schema--></a>
                    </li>
                    <?php if(Auth::check()==false): ?>
                    <li>
                        <a href="<?php echo e(route('user')); ?>" title="User"><span style="background-image: url(src/images/user.png)"></span><!--User--></a>
                    </li>
                    <?php endif; ?>
                </ul>

                <!-- Login / Logout -->
                <div id='access'>
                    <div>Webmaster (<a href="#">Logout</a>)</div> 
                </div>
            </div>

           <!-- вывод драйверов -->
<h1>Drivers</h1>
           <div class="drivers">
               <ul>
               <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><p><b>ID:</b><?php echo e($driver->id); ?></p></li>
            <li><p><b>Name:</b><?php echo e($driver->name); ?></p></li>
            <li><p><b>Birth Date:</b><?php echo e($driver->birth_date); ?></p></li>
            <li><p><b>Email:</b><?php echo e($driver->email); ?></p></li>
            <li><p><b>Phone:</b><?php echo e($driver->phone); ?></p></li>
            <li><p><b>Type:</b><?php echo e($driver->type); ?></p></li>
            <li><p><b>Avatar:</b><?php echo e($driver->avatar); ?></p></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </ul>
           </div>






                                        <!-- content -->



                                        </div>
                                        <div class="span-5 last">
                                            <div id="sidebar">
                                                <div class="portlet" >
                                                    <div class="portlet-decoration">
                                                        <div class="portlet-title">Operations</div>
                                                    </div>
                                                    <div class="portlet-content">
                                                        <ul class="operations" >
                                                            <li><a href="#list">List Driver</a></li>
                                                            <li><a href="#manage">Manage Driver</a></li>
                                                        </ul></div>
                                                </div>	
                                            </div><!-- sidebar -->
                                        </div>

                                        <div class="clear"></div>

                                        <div id="footer">
                                            <ul>
                                                <li class="sitemap"><a href="#">Site Map</a></li>
                                                <li class="copyr"><a href="#">Copyright &copy; 2013 by LVB</a></li>
                                                <li class="allright"><a href="#">All Rights Reserved. <br>By WorldSkills International</a></li>
                                            </ul>
                                        </div><!-- footer -->

                                        </div><!-- page -->

                                        </body>
                                        </html>
<?php /**PATH C:\OSPanel\domains\borovinskikh\p4\resources\views/listDriver.blade.php ENDPATH**/ ?>