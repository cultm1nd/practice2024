<h1>Edit Vehicle</h1>

<form enctype="multipart/form-data" action="<?php echo e(route('updateVehicle', $vehicle->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row">
        <label for="Vehicle_name">Name</label>
        <input size="50" maxlength="50" name="name" id="Vehicle_name" type="text" value="<?php echo e($vehicle->name); ?>" required>
    </div>

    <div class="row">
        <label for="Vehicle_capacity">Capacity</label>
        <input size="50" maxlength="50" name="capacity" id="Vehicle_capacity" type="text" value="<?php echo e($vehicle->capacity); ?>" required>
    </div>

    <div class="row">
        <label for="Vehicle_type">Type</label>
        <select name="type" id="Vehicle_type">
            <option value="Tram" <?php echo e($vehicle->type == 'Tram' ? 'selected' : ''); ?>>Tram</option>
            <option value="Bus" <?php echo e($vehicle->type == 'Bus' ? 'selected' : ''); ?>>Bus</option>
            <option value="Nightliner" <?php echo e($vehicle->type == 'Nightliner' ? 'selected' : ''); ?>>Nightliner</option>
            <option value="Regionalbus" <?php echo e($vehicle->type == 'Regionalbus' ? 'selected' : ''); ?>>Regionalbus</option>
        </select>
    </div>

    <div class="row buttons">
        <input type="submit" value="Update">
    </div>
</form><?php /**PATH C:\OSPanel\domains\borovinskikh\p4\resources\views/editVehicle.blade.php ENDPATH**/ ?>