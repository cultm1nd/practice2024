<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\Report;

class AdminController extends Controller
// { 
//     public function index()
//     {
         
//         $reports = Report::all();
//         return view('admin.index', compact('reports'));
//     }

  
// public function updateStatus(Request $request)
// {
//     $reportId = $request->input('id');
//     $newStatus = $request->input('status');

//     if (!$reportId || !$newStatus) {
//         return redirect()->back()->withInput()->with('error', 'Неверные данные');
//     }

//     $report = Report::findOrFail($reportId);

//     if ($report->status === 'new' && in_array($newStatus, ['confirmed', 'rejected'])) {
//         $report->update(['status' => $newStatus]);
//         return redirect()->route('admin')->with('success', 'Статус изменен успешно');
//     } else {
//         return redirect()->back()->withInput()->with('error', 'Статус уже изменен');
//     }
// }

}