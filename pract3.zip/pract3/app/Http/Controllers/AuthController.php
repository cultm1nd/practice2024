<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function showRegistrationForm()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            // 'phone' => "required|string|regex:/^\+7\d{3}-\d{3}-\d{2}-\d{2}$/i",
            'name' => "required|string|regex:/^[А-Яа-яЁё]+$/u",
            'surname' => "required|string|regex:/^[А-Яа-яЁё]+$/u",
            'patr' => "required|string|regex:/^[А-Яа-яЁё]+$/u",
            'password' => ['required', 'string', 'min:4', 'confirmed'],


        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        User::create([
            'username' => $request->input('name'),
            'surname' => $request->input('surname'),
            'phone' => $request->input('phone'),
            'email' => $request->input('email'),
            'login' => $request->input('login'),
            'patronymic' => $request->input('patr'),
            'password' => Hash::make($request->input('password')),
            'role_id' => 2

        ]);

        Auth::attempt(['email' => $request->input('email'), 'password' => $request->input('password')]);

        return redirect()->route('home')->with('success', 'Вы успешно зарегистрировались!');
    }


    protected function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'login' => ['required'],
            'password' => ['required'],
        ]);

        if (!Auth::attempt($credentials)) {
            return redirect()->back()->withErrors(['login' => 'Неверный логин или пароль']);
        }

        $user = Auth::user();
        $request->session()->regenerate();

        // return redirect()->intended('/dashboard');

        if ($user->role === 'Администратор') {
            return redirect()->route('admin')->with('success', 'Добро пожаловать в админ-панель!');
        }

        return redirect('/');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/');
    }
}
