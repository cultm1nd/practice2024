<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\Report;
use App\Models\Booking;
use App\Models\Event;

class CartController  extends Controller
{
    public function index()
    {
        $bookings = Auth::id() ? Booking::whereUserId(Auth::id())->get() : collect();

        return view('cart.index', [
            'bookings' => $bookings,
            'totalPrice' => $this->calculateTotalPrice($bookings),
        ]);
    }

    public function checkout(Request $request)
    {


        $bookingId = $request->input('booking_id');


        $booking = Booking::find($bookingId);

        if (!$booking) {
            return redirect()->back()->with('error', 'Бронирование не найдено. Пожалуйста, попробуйте снова.');
        }

        $booking->update(['payed' => 1]);

        $booking->tickets()->each(function ($ticket) {
            $ticket->update(['is_used' => true]);
        });

        return redirect()->route('cart.index')->with('success', 'Оплата успешно произведена!');
    }


    private function calculateTotalPrice($bookings)
    {
        return $bookings->sum('total_price');
    }
}
