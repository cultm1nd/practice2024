<footer>
    <div class="container">
        <div class="links">
            <a href="#">Главная</a>
            <a href="#">Афиша</a>


        </div>
        <div class="col">
            <div class="logo">
                <img src="{{ asset('logo.svg') }}" alt="">
            </div>
            <div class="btn">Купить билет</div>
            
        </div>
    </div>
</footer>

 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
