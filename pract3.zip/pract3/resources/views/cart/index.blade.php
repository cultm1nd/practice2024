@include('blocks.header')
<h1>Ваша корзина</h1>

@if ($bookings->count())
    <table class="table">
        <thead>
            <tr>
                <th>Мероприятие</th>
                <th>Цена</th>
                {{-- <th>Действия</th> --}}
            </tr>
        </thead>
        <tbody>
            @foreach ($bookings as $booking)
                <tr>
                    <td>{{ $booking->event->title }}</td>
                    <td>{{ $booking->total_price }}</td>
                    <td>
                        <form action="{{ route('cart.checkout') }}" method="POST">
                            @csrf
                            <input type="hidden" name="booking_id" value="{{ $booking->id }}">
                            {{-- <input class="form-check-input" type="checkbox" name="bookings[]" value="{{ $booking->id }}" id="booking_{{ $booking->id }}">
                            <label class="form-check-label" for="booking_{{ $booking->id }}">Оплатить</label> --}}
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

 



    <div class="mt-3  ">
        <strong>Итоговая сумма:</strong> {{ $totalPrice }}     
        <br>

        @if ($booking->is_paid)
        <td>Оплачен</td>
        @else
            <td><form action="{{ route('cart.checkout') }}" method="POST">
                    @csrf
                    <input type="hidden" name="booking_id" value="{{ $booking->id }}">
                    <button type="submit" class="btn btn-primary">Оплатить выбранные мероприятия</button>
                </form></td>
        @endif
    </div>

    <hr>
 

 @else
    <p>Ваша корзина пуста.</p>
@endif
