
@include('blocks.header')
@push('styles')
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
@endpush

<link href="{{ asset('css/ticket-styles.css') }}" rel="stylesheet">
<style>
    .seating-chart {
        margin: 20px 0;
    }
    .row {
        margin-bottom: 20px;
        width: 100%; 
        display: flex;
        justify-content: space-around;
    }
    .seats {
        display: flex;
        flex-wrap: wrap;
        width: 100%; 
        justify-content: space-around;
    }
    .seat {
        background-color: #4CAF50; /* Доступное место */
        padding: 10px;
        text-align: center;
        cursor: pointer;
        border-radius: 5px;
        margin: 5px;
        padding: 20px
     }
    .seat.disabled {
        background-color: #f44336; /* Недоступное место */
        cursor: not-allowed;
    }
</style>
<h1>Бронирование билетов на мероприятие</h1>
 

 

<section class="tickets">
    <div class="container">
        <h2>Бронирование билетов</h2>

        <form method="POST" action="{{ route('ticketBooking.store', ['eventId' => $event->id]) }}">
            @csrf
            <input type="hidden" name="event_id" value="{{ $event->id }}">

            <div class="seating-chart">
                <div class="scena" style="width: 100%; background-color:rgb(221, 221, 221); text-align: center; ">
                    <h1>Сцена</h1>
                </div>
                @foreach($rows as $row)
                    <div class="row d-flex"   data-row="{{ $row }}">
                        {{-- <h3>Ряд {{ $row }}</h3> --}}
                        
                         <div class="seats">
                            @foreach($seats as $seat)
                                @if($seat->row == $row)
                                     <div class="seat {{ !$seat->is_available ? 'disabled' : '' }}" data-seat-id="{{ $seat->id }}">
                                        <input type="checkbox" name="seats[]" value="{{ $seat->id }}" id="seat-{{ $seat->id }}" {{ !$seat->is_available ? 'disabled' : '' }} />
                                        <label for="seat-{{ $seat->id }}">{{ $seat->seat_number }}</label>
                                    </div>
                                @endif
                            @endforeach
                        </div>
                    </div>
                @endforeach
            </div>

            <button type="submit" class="btn btn-primary">Продолжить бронирование</button>
        </form>
    </div>
</section>

@if(session('success'))
    <div id="successToast" class="toast fade show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="true" data-bs-delay="5000">
        <div class="toast-header">
            <strong class="me-auto">Успешное бронирование!</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Закрыть"></button>
        </div>
        <div class="toast-body">
            Ваш заказ успешно подтвержден.
        </div>
    </div>
@endif

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var toastElList = [].slice.call(document.querySelectorAll('.toast'));
        var toastList = toastElList.map(function(toastEl) {
            return new bootstrap.Toast(toastEl);
        });
    });
</script>
