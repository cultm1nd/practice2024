<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminController;



use App\Http\Controllers\Controller;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\TicketBookingController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\CartController;




/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('home');




Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Дополнительные маршруты для регистрации
Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);

Route::get('/admin', [AdminController::class, 'index'])->name('admin');



// Публичные маршруты
Route::get('/', [Controller::class, 'index'])->name('home');
Route::get('/events/{id}', 'App\Http\Controllers\EventController@show')->name('event.show');
Route::get('/contact', [ContactController::class, 'index'])->name('contact');
Route::get('/about', [AboutController::class, 'index'])->name('about');

// Маршруты для покупки билетов

Route::get('/events/{eventId}/book', [TicketBookingController::class, 'indexBooking'])->name('ticketBooking.index');
Route::post('/events/{eventId}/book', [TicketBookingController::class, 'store'])->name('ticketBooking.store');
Route::delete('/events/{eventId}/cancel-booking/{bookingId}', [TicketBookingController::class, 'cancelBooking'])->name('ticketBooking.cancel');




// афиша
Route::get('/afisha', [EventController::class, 'indexEvent'])->name('afisha'); // Список мероприятий

Route::middleware(['auth'])->group(function () {
    Route::get('/admin', [AdminController::class, 'index'])->name('admin.dashboard'); // Панель управления
    Route::get('/admin/news', [AdminController::class, 'newsIndex'])->name('admin.news.index'); // Список новостей
    Route::get('/admin/bookings', [AdminController::class, 'bookingIndex'])->name('admin.bookings.index'); // Список бронирований

    // Маршруты для подтверждения и отклонения бронирований
    Route::post('/admin/approve-booking/{id}', [AdminController::class, 'approveBooking'])->name('approveBooking');
    Route::post('/admin/reject-booking/{id}', [AdminController::class, 'rejectBooking'])->name('rejectBooking');

    // Маршруты для создания и редактирования новостей
    Route::get('/admin/news/create', [AdminController::class, 'createNews'])->name('news.create');
    Route::post('/admin/news', [AdminController::class, 'storeNews'])->name('news.store');
    Route::get('/admin/news/{id}/edit', [AdminController::class, 'editNews'])->name('news.edit');
    Route::patch('/admin/news/{id}', [AdminController::class, 'updateNews'])
        ->name('news.update')
        ->middleware('auth');
    Route::delete('/admin/news/{id}', [AdminController::class, 'destroyNews'])->name('news.destroy');


    Route::get('/admin/bookings/create', [AdminController::class, 'createBooking'])->name('bookings.create');
    Route::post('/admin/bookings', [AdminController::class, 'storeBooking'])->name('bookings.store');
    Route::get('/admin/bookings/{id}/edit', [AdminController::class, 'editBooking'])->name('bookings.edit');
    Route::patch('/admin/bookings/{id}', [AdminController::class, 'updateBooking'])->name('bookings.update');

    // Удаление новостей, театров и бронирований
    Route::delete('/news/{id}', [AdminController::class, 'destroyNews'])->name('news.destroy');
});
Route::get('/admin/news/create', [AdminController::class, 'createNews'])->name('news.create');
Route::post('/admin/news', [AdminController::class, 'storeNews'])->name('news.store');


Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::post('cart/checkout', [CartController::class, 'checkout'])->name('cart.checkout');