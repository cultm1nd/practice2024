    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
 <?php echo $__env->make('blocks.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
 <style>
     #mainCarousel,
     .carousel-inner,
     .carousel-item,
     .carousel-item img,
     .carousel-item .row {
         height: 100%;
         margin: 0px !important;
     }

     .carousel-caption {
         justify-content: center;
         align-items: center;
     }

     .row {
         height: 100%;
         margin: 0px !important;
         padding: 0px;
         width: 100%;
     }
 </style>
 <main>
     <section class="hero mainSlider">
         <div id="mainCarousel" class="carousel slide" data-bs-ride="carousel">
             <div class="carousel-inner">
                 <?php $__currentLoopData = $allEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                         <img src="<?php echo e(asset('/images/1 screen.png')); ?>" class="d-block w-100" alt="...">
                         <div class="container carousel-caption d-none d-md-block">
                             <div class="row align-items-center">
                                 <div class="col-md-10">
                                     <h2><?php echo e($event->title); ?></h2>
                                     <div class="info">
                                       
                                         <div>
                                            <p>Дата мероприятия:</p>
                                            <p><?php echo e($event->date); ?></p>
                                          </div>
                                         <div>
                                             <p>Афиша:</p>
                                             <p><span>ул.Пушкина, 41</span></p>
                                         </div>
                                     </div>
                                     <a href="<?php echo e(route('event.show', $event->id)); ?>" class="btn" style="color: white">Подробнее</a>
                                 </div>
                                 

                             </div>
                         </div>
                     </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
             <button class="carousel-control-prev" style="background-color: transparent" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
                 <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                 <span class="visually-hidden">Previous</span>
             </button>
             <button  style="background-color: transparent"  class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
                 <span class="carousel-control-next-icon" aria-hidden="true"></span>
                 <span class="visually-hidden">Next</span>
             </button>
         </div>
     </section>
     <section class="recommendations">
         <div class="container">
             <div class="flex j-btw">
                 <h3>РЕКОМЕНДУЕМ</h3>
                 <div class="navigation">
                     <button id="recomendation-arrow-left" style="background-color: transparent"  class="arrow left" sty>
                         <img src="<?php echo e(asset('arrow-left.svg')); ?>" alt="">
                     </button>
                     <button class="arrow right" style="background-color: transparent" id="recomendation-arrow-right">
                         <img src="<?php echo e(asset('arrow-right.svg')); ?>" alt="">
                     </button>
                 </div>
             </div>
             <div class="recommendations-wrapper">
                 <div class="slider">
                     <?php $__currentLoopData = $allEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="recommendation" style="max-width: 300px; min-width: 300px; background-image: url('<?php echo e(asset('images/event.png')); ?>');">
                        <div class="time">
                                 <div class="col">
                                     <p><?php echo e($event->start_date); ?></p>
                                     <p> <?php echo e($event->start_time); ?></p>
                                 </div>
                                 <span>16+</span>
                             </div>
                             <div class="">
                                 <h4><?php echo e($event->title); ?></h4>
                                 <p><?php echo e($event->description); ?></p>
                             </div>
                             <a href="<?php echo e(route('event.show', $event->id)); ?>" class="btn">Подробнее</a>

                             

                         </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
             </div>
         </div>
     </section>

      
 </main>
 <?php echo $__env->make('blocks.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\OSPanel\domains\borovinskikh\4course\pract3\resources\views/home.blade.php ENDPATH**/ ?>