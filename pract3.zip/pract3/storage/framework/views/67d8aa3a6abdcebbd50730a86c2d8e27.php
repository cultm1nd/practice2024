<?php echo $__env->make('blocks.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Ваша корзина</h1>

<?php if($bookings->count()): ?>
    <table class="table">
        <thead>
            <tr>
                <th>Мероприятие</th>
                <th>Цена</th>
                
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($booking->event->title); ?></td>
                    <td><?php echo e($booking->total_price); ?></td>
                    <td>
                        <form action="<?php echo e(route('cart.checkout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">
                            
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

 



    <div class="mt-3  ">
        <strong>Итоговая сумма:</strong> <?php echo e($totalPrice); ?>     
        <br>

        <?php if($booking->is_paid): ?>
        <td>Оплачен</td>
        <?php else: ?>
            <td><form action="<?php echo e(route('cart.checkout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">
                    <button type="submit" class="btn btn-primary">Оплатить выбранные мероприятия</button>
                </form></td>
        <?php endif; ?>
    </div>

    <hr>
 

 <?php else: ?>
    <p>Ваша корзина пуста.</p>
<?php endif; ?>
<?php /**PATH C:\OSPanel\domains\borovinskikh\4course\pract3\resources\views/cart/index.blade.php ENDPATH**/ ?>