<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<?php echo $__env->make('blocks.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/event.css')); ?>">
<style>
    .icon-calendar {
        background-image: url('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"%3E%3Cpath d="M21 18.25V19.75a2.25 2.25 0 0 1-2.25 2.25H4.75A2.25 2.25 0 0 1 2.5 16.5H5.25a2.25 2.25 0 1 1 0-4.5 2.25 2.25 0 0 1 4 0z"/%3E%3Cpath d="M22 12a2 2 0 0 1 2 2v1m-2 4a2 2 0 0 1-2 2H3m14-6a2 2 0 0 1-2 2v3a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h3.5a2 2 0 0 1 2 2v3zm-9-9a2 2 0 0 0-2-2 2 2 0 0 0 2-2h3.5a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h3.5z"/%3E%3C/svg%3E');
        background-repeat: no-repeat;
        background-size: contain;
        height: 24px;
        width: 24px;
    }

    .icon-clock {
        background-image: url('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"%3E%3Ccircle cx="12" cy="12" r="10"/%3E%3Cline x1="12" y1="8" x2="12" y2="16"/%3E%3Cline x1="8" y1="12" x2="16" y2="12"/%3E%3C/svg%3E');
        background-repeat: no-repeat;
        background-size: contain;
        height: 24px;
        width: 24px;
    }

    .ticket{
        width: max-content;
        padding: 10px 20px;
        background-color: black;
        border: 1px dotted gray;
        margin: auto;
        color: white
    }
</style>
<main>

    <section class="hero">
        <div class="container">
            <h1><?php echo e($event->title); ?></h1>

            <div class="info">
                 

                <div>
                    <p>Дата мероприятия:</p>
                    <p><?php echo e($event->date); ?></p>
                  </div>
                <div>
                    <p>Место проведения:</p>
                    <p><span>Адрес театра</span></p>
                </div>
            </div>


            <div class="  ticket">  Стоимость билетов: <?php echo e($minPrice); ?> - <?php echo e($maxPrice); ?> ₽</div>
        </div>
    </section>

    <?php if(session('success')): ?>
        <div id="successMessage" class="alert alert-success mt-5 position-fixed top-0 end-50 p-3">
            <?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <section class="description">
        <div class="container">
            <h2>Описание спектакля</h2>
            <p><?php echo e($event->description); ?></p>
        </div>
    </section>


    <section class="tickets">
        <div class="container">
            <h2>Билеты</h2>

            

            <?php if(Auth::check()): ?>
                <a href="<?php echo e(route('ticketBooking.store', [$event])); ?>" class="btn btn-primary mb-3">Купить билеты</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Войти</a>
                <a href="<?php echo e(route('register')); ?>">Регистрация</a>
            <?php endif; ?>
        </div>
    </section>

</main>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
    integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
    integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const successMessage = document.getElementById('successMessage');

        // Показываем сообщение
        successMessage.style.display = 'block';

        // Ожидаем 5 секунд
        setTimeout(function() {
            // Скрываем сообщение после 5 секунд
            successMessage.style.display = 'none';
        }, 5000);
    });
</script>
<?php echo $__env->make('blocks.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\OSPanel\domains\borovinskikh\4course\pract3\resources\views/events/event.blade.php ENDPATH**/ ?>