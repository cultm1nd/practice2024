
<?php echo $__env->make('blocks.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startPush('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<link href="<?php echo e(asset('css/ticket-styles.css')); ?>" rel="stylesheet">
<style>
    .seating-chart {
        margin: 20px 0;
    }
    .row {
        margin-bottom: 20px;
        width: 100%; 
        display: flex;
        justify-content: space-around;
    }
    .seats {
        display: flex;
        flex-wrap: wrap;
        width: 100%; 
        justify-content: space-around;
    }
    .seat {
        background-color: #4CAF50; /* Доступное место */
        padding: 10px;
        text-align: center;
        cursor: pointer;
        border-radius: 5px;
        margin: 5px;
        padding: 20px
     }
    .seat.disabled {
        background-color: #f44336; /* Недоступное место */
        cursor: not-allowed;
    }
</style>
<h1>Бронирование билетов на мероприятие</h1>
 

 

<section class="tickets">
    <div class="container">
        <h2>Бронирование билетов</h2>

        <form method="POST" action="<?php echo e(route('ticketBooking.store', ['eventId' => $event->id])); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="event_id" value="<?php echo e($event->id); ?>">

            <div class="seating-chart">
                <div class="scena" style="width: 100%; background-color:rgb(221, 221, 221); text-align: center; ">
                    <h1>Сцена</h1>
                </div>
                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row d-flex"   data-row="<?php echo e($row); ?>">
                        
                        
                         <div class="seats">
                            <?php $__currentLoopData = $seats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($seat->row == $row): ?>
                                     <div class="seat <?php echo e(!$seat->is_available ? 'disabled' : ''); ?>" data-seat-id="<?php echo e($seat->id); ?>">
                                        <input type="checkbox" name="seats[]" value="<?php echo e($seat->id); ?>" id="seat-<?php echo e($seat->id); ?>" <?php echo e(!$seat->is_available ? 'disabled' : ''); ?> />
                                        <label for="seat-<?php echo e($seat->id); ?>"><?php echo e($seat->seat_number); ?></label>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <button type="submit" class="btn btn-primary">Продолжить бронирование</button>
        </form>
    </div>
</section>

<?php if(session('success')): ?>
    <div id="successToast" class="toast fade show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="true" data-bs-delay="5000">
        <div class="toast-header">
            <strong class="me-auto">Успешное бронирование!</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Закрыть"></button>
        </div>
        <div class="toast-body">
            Ваш заказ успешно подтвержден.
        </div>
    </div>
<?php endif; ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var toastElList = [].slice.call(document.querySelectorAll('.toast'));
        var toastList = toastElList.map(function(toastEl) {
            return new bootstrap.Toast(toastEl);
        });
    });
</script>
<?php /**PATH C:\OSPanel\domains\borovinskikh\4course\pract3\resources\views/events/ticket-booking.blade.php ENDPATH**/ ?>